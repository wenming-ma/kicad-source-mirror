#include "math_operations.h"
#include <cmath>

long MathOperations::factorial(int n) {
    if (n <= 1) return 1;
    return n * factorial(n - 1);
}

double MathOperations::power(double base, int exponent) {
    if (exponent == 0) return 1;
    if (exponent < 0) return 1.0 / power(base, -exponent);
    
    double result = 1;
    for (int i = 0; i < exponent; i++) {
        result *= base;
    }
    return result;
}

bool MathOperations::isPrime(int n) {
    if (n <= 1) return false;
    if (n <= 3) return true;
    if (n % 2 == 0 || n % 3 == 0) return false;
    
    for (int i = 5; i * i <= n; i += 6) {
        if (n % i == 0 || n % (i + 2) == 0) {
            return false;
        }
    }
    return true;
}

int MathOperations::gcd(int a, int b) {
    if (b == 0) return a;
    return gcd(b, a % b);
}

std::vector<int> MathOperations::primeFactors(int n) {
    std::vector<int> factors;
    
    for (int i = 2; i * i <= n; i++) {
        while (n % i == 0) {
            factors.push_back(i);
            n /= i;
        }
    }
    
    if (n > 1) {
        factors.push_back(n);
    }
    
    return factors;
}

double MathOperations::sqrt(double x) {
    if (x < 0) return -1;
    if (x == 0) return 0;
    
    double guess = x / 2.0;
    double epsilon = 1e-10;
    
    while (std::abs(guess * guess - x) > epsilon) {
        guess = (guess + x / guess) / 2.0;
    }
    
    return guess;
}