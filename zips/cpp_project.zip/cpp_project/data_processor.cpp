#include "data_processor.h"
#include <algorithm>
#include <numeric>
#include <sstream>
#include <regex>

template<typename T>
std::vector<T> DataProcessor<T>::sort(std::vector<T> data) {
    std::sort(data.begin(), data.end());
    return data;
}

template<typename T>
T DataProcessor<T>::findMax(const std::vector<T>& data) {
    if (data.empty()) return T{};
    return *std::max_element(data.begin(), data.end());
}

template<typename T>
T DataProcessor<T>::findMin(const std::vector<T>& data) {
    if (data.empty()) return T{};
    return *std::min_element(data.begin(), data.end());
}

template<typename T>
double DataProcessor<T>::average(const std::vector<T>& data) {
    if (data.empty()) return 0.0;
    auto sum = std::accumulate(data.begin(), data.end(), T{});
    return static_cast<double>(sum) / data.size();
}

template<typename T>
std::vector<T> DataProcessor<T>::filter(const std::vector<T>& data, T threshold) {
    std::vector<T> filtered;
    std::copy_if(data.begin(), data.end(), std::back_inserter(filtered),
                 [threshold](const T& item) { return item > threshold; });
    return filtered;
}

template<typename T>
std::map<T, int> DataProcessor<T>::frequency(const std::vector<T>& data) {
    std::map<T, int> freq;
    for (const auto& item : data) {
        freq[item]++;
    }
    return freq;
}

template class DataProcessor<int>;
template class DataProcessor<double>;

std::vector<std::string> StringProcessor::processLines(const std::vector<std::string>& lines) {
    std::vector<std::string> processed;
    for (const auto& line : lines) {
        if (!line.empty() && line[0] != '#') {
            processed.push_back(line);
        }
    }
    return processed;
}

std::map<std::string, int> StringProcessor::wordCount(const std::string& text) {
    std::map<std::string, int> count;
    std::stringstream ss(text);
    std::string word;
    
    while (ss >> word) {
        std::transform(word.begin(), word.end(), word.begin(), ::tolower);
        count[word]++;
    }
    
    return count;
}

std::string StringProcessor::removeSpecialChars(const std::string& text) {
    std::regex special_chars("[^a-zA-Z0-9\\s]");
    return std::regex_replace(text, special_chars, "");
}