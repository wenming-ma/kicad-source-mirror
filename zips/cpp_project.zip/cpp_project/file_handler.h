#pragma once
#include <string>
#include <vector>

class FileHandler {
public:
    bool writeToFile(const std::string& filename, const std::string& content);
    std::string readFromFile(const std::string& filename);
    bool fileExists(const std::string& filename);
    std::vector<std::string> listFiles(const std::string& directory);
    bool deleteFile(const std::string& filename);
};