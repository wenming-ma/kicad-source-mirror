#include "logger.h"
#include <iostream>
#include <chrono>
#include <iomanip>
#include <sstream>

Logger::Logger(const std::string& filename, LogLevel level) 
    : logFile(filename), currentLevel(level) {
    fileStream.open(logFile, std::ios::app);
}

Logger::~Logger() {
    if (fileStream.is_open()) {
        fileStream.close();
    }
}

void Logger::setLogLevel(LogLevel level) {
    currentLevel = level;
}

void Logger::setLogFile(const std::string& filename) {
    if (fileStream.is_open()) {
        fileStream.close();
    }
    logFile = filename;
    fileStream.open(logFile, std::ios::app);
}

void Logger::debug(const std::string& message) {
    writeLog(LogLevel::DEBUG, message);
}

void Logger::info(const std::string& message) {
    writeLog(LogLevel::INFO, message);
}

void Logger::warning(const std::string& message) {
    writeLog(LogLevel::WARNING, message);
}

void Logger::error(const std::string& message) {
    writeLog(LogLevel::ERROR, message);
}

void Logger::writeLog(LogLevel level, const std::string& message) {
    if (level < currentLevel) return;
    
    std::string timestamp = getCurrentTime();
    std::string levelStr = levelToString(level);
    
    std::string logEntry = "[" + timestamp + "] [" + levelStr + "] " + message;
    
    std::cout << logEntry << std::endl;
    
    if (fileStream.is_open()) {
        fileStream << logEntry << std::endl;
        fileStream.flush();
    }
}

std::string Logger::getCurrentTime() {
    auto now = std::chrono::system_clock::now();
    auto time_t = std::chrono::system_clock::to_time_t(now);
    
    std::stringstream ss;
    ss << std::put_time(std::localtime(&time_t), "%Y-%m-%d %H:%M:%S");
    return ss.str();
}

std::string Logger::levelToString(LogLevel level) {
    switch (level) {
        case LogLevel::DEBUG: return "DEBUG";
        case LogLevel::INFO: return "INFO";
        case LogLevel::WARNING: return "WARNING";
        case LogLevel::ERROR: return "ERROR";
        default: return "UNKNOWN";
    }
}