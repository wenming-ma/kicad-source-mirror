#pragma once
#include <vector>
#include <map>
#include <string>

template<typename T>
class DataProcessor {
public:
    std::vector<T> sort(std::vector<T> data);
    T findMax(const std::vector<T>& data);
    T findMin(const std::vector<T>& data);
    double average(const std::vector<T>& data);
    std::vector<T> filter(const std::vector<T>& data, T threshold);
    std::map<T, int> frequency(const std::vector<T>& data);
};

class StringProcessor {
public:
    std::vector<std::string> processLines(const std::vector<std::string>& lines);
    std::map<std::string, int> wordCount(const std::string& text);
    std::string removeSpecialChars(const std::string& text);
};