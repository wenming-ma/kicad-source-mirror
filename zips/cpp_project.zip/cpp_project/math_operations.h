#pragma once
#include <vector>

class MathOperations {
public:
    long factorial(int n);
    double power(double base, int exponent);
    bool isPrime(int n);
    int gcd(int a, int b);
    std::vector<int> primeFactors(int n);
    double sqrt(double x);
};