#pragma once
#include <string>
#include <fstream>

enum class LogLevel {
    DEBUG = 0,
    INFO = 1,
    WARNING = 2,
    ERROR = 3
};

class Logger {
private:
    std::string logFile;
    LogLevel currentLevel;
    std::ofstream fileStream;

public:
    Logger(const std::string& filename = "app.log", LogLevel level = LogLevel::INFO);
    ~Logger();
    
    void setLogLevel(LogLevel level);
    void setLogFile(const std::string& filename);
    
    void debug(const std::string& message);
    void info(const std::string& message);
    void warning(const std::string& message);
    void error(const std::string& message);
    
private:
    void writeLog(LogLevel level, const std::string& message);
    std::string getCurrentTime();
    std::string levelToString(LogLevel level);
};