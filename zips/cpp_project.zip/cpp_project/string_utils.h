#pragma once
#include <string>
#include <vector>

class StringUtils {
public:
    std::string reverse(const std::string& str);
    std::string toUpper(const std::string& str);
    std::string toLower(const std::string& str);
    std::vector<std::string> split(const std::string& str, char delimiter);
    std::string trim(const std::string& str);
};