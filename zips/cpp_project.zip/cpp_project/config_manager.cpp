#include "config_manager.h"
#include <fstream>
#include <sstream>

ConfigManager::ConfigManager(const std::string& filename) : configFile(filename) {
    loadConfig();
}

bool ConfigManager::loadConfig() {
    std::ifstream file(configFile);
    if (!file.is_open()) {
        return false;
    }
    
    config.clear();
    std::string line;
    
    while (std::getline(file, line)) {
        if (line.empty() || line[0] == '#') continue;
        
        size_t pos = line.find('=');
        if (pos != std::string::npos) {
            std::string key = line.substr(0, pos);
            std::string value = line.substr(pos + 1);
            
            // Trim whitespace
            key.erase(0, key.find_first_not_of(" \t"));
            key.erase(key.find_last_not_of(" \t") + 1);
            value.erase(0, value.find_first_not_of(" \t"));
            value.erase(value.find_last_not_of(" \t") + 1);
            
            config[key] = value;
        }
    }
    
    file.close();
    return true;
}

bool ConfigManager::saveConfig() {
    std::ofstream file(configFile);
    if (!file.is_open()) {
        return false;
    }
    
    for (const auto& pair : config) {
        file << pair.first << " = " << pair.second << "\n";
    }
    
    file.close();
    return true;
}

std::string ConfigManager::getValue(const std::string& key, const std::string& defaultValue) {
    auto it = config.find(key);
    return (it != config.end()) ? it->second : defaultValue;
}

void ConfigManager::setValue(const std::string& key, const std::string& value) {
    config[key] = value;
}

bool ConfigManager::hasKey(const std::string& key) {
    return config.find(key) != config.end();
}

void ConfigManager::removeKey(const std::string& key) {
    config.erase(key);
}

void ConfigManager::clear() {
    config.clear();
}

std::map<std::string, std::string> ConfigManager::getAllConfig() {
    return config;
}