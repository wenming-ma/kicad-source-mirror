#include "file_handler.h"
#include <fstream>
#include <filesystem>

bool FileHandler::writeToFile(const std::string& filename, const std::string& content) {
    std::ofstream file(filename);
    if (file.is_open()) {
        file << content;
        file.close();
        return true;
    }
    return false;
}

std::string FileHandler::readFromFile(const std::string& filename) {
    std::ifstream file(filename);
    std::string content;
    
    if (file.is_open()) {
        std::string line;
        while (std::getline(file, line)) {
            content += line + "\n";
        }
        file.close();
    }
    
    return content;
}

bool FileHandler::fileExists(const std::string& filename) {
    return std::filesystem::exists(filename);
}

std::vector<std::string> FileHandler::listFiles(const std::string& directory) {
    std::vector<std::string> files;
    
    try {
        for (const auto& entry : std::filesystem::directory_iterator(directory)) {
            if (entry.is_regular_file()) {
                files.push_back(entry.path().filename().string());
            }
        }
    } catch (...) {
        // Handle error silently
    }
    
    return files;
}

bool FileHandler::deleteFile(const std::string& filename) {
    return std::filesystem::remove(filename);
}