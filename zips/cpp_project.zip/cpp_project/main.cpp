#include <iostream>
#include "calculator.h"
#include "string_utils.h"
#include "file_handler.h"
#include "math_operations.h"
#include "data_processor.h"
#include "config_manager.h"
#include "logger.h"

int main() {
    std::cout << "C++ Project Demo\n";
    
    Calculator calc;
    std::cout << "Calculator: 5 + 3 = " << calc.add(5, 3) << "\n";
    
    StringUtils utils;
    std::cout << "String utils: reversed 'hello' = " << utils.reverse("hello") << "\n";
    
    MathOperations math;
    std::cout << "Math: factorial(5) = " << math.factorial(5) << "\n";
    
    Logger logger;
    logger.info("Application started successfully");
    
    return 0;
}