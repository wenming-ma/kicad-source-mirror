#pragma once
#include <string>
#include <map>

class ConfigManager {
private:
    std::map<std::string, std::string> config;
    std::string configFile;

public:
    ConfigManager(const std::string& filename = "config.txt");
    
    bool loadConfig();
    bool saveConfig();
    
    std::string getValue(const std::string& key, const std::string& defaultValue = "");
    void setValue(const std::string& key, const std::string& value);
    
    bool hasKey(const std::string& key);
    void removeKey(const std::string& key);
    
    void clear();
    std::map<std::string, std::string> getAllConfig();
};