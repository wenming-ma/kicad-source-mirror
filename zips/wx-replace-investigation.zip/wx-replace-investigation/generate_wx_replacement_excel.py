#!/usr/bin/env python3
"""
生成wxWidgets替换方案的Excel表格
"""

import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import PatternFill, Font, Alignment, Border, Side
from openpyxl.utils.dataframe import dataframe_to_rows

def create_wx_replacement_excel():
    """创建wxWidgets替换方案Excel表格"""
    
    # 准备数据
    data = [
        # 1. 字符串和数据类型
        ["字符串和数据类型", "wxString", "Unicode字符串类", "QString", "std::string (UTF-8)\nstd::u16string (UTF-16)", "功能最接近，API相似"],
        ["字符串和数据类型", "wxArrayString", "字符串数组", "QStringList", "std::vector<std::string>", "Qt版本更易用"],
        ["字符串和数据类型", "wxStringTokenize()", "字符串分词", "QString::split()", "std::regex\nboost::split()", "Qt方法更直观"],
        ["字符串和数据类型", "wxVariant", "通用数据容器", "QVariant", "std::variant (C++17)\nboost::variant", "类型安全的现代方案"],
        ["字符串和数据类型", "wxAny", "类型擦除容器", "QVariant", "std::any (C++17)\nboost::any", "现代C++替代方案"],
        ["字符串和数据类型", "wxBase64Encode/Decode()", "Base64编码解码", "QByteArray::toBase64()\nQByteArray::fromBase64()", "openssl/base64.h\nboost::beast::detail::base64", "Qt集成度更好"],
        
        # 2. 文件和路径操作
        ["文件和路径操作", "wxFileName", "文件路径操作", "QFileInfo\nQDir", "std::filesystem::path (C++17)\nboost::filesystem::path", "现代C++标准更优"],
        ["文件和路径操作", "wxFileName::Assign()", "路径赋值", "QFileInfo::setFile()", "std::filesystem::path::assign()", "功能等价"],
        ["文件和路径操作", "wxFileName::GetFullPath()", "获取绝对路径", "QFileInfo::absoluteFilePath()", "std::filesystem::absolute()", "性能相当"],
        ["文件和路径操作", "wxFileName::FileExists()", "文件存在检查", "QFile::exists()", "std::filesystem::exists()", "STL版本更轻量"],
        ["文件和路径操作", "wxFileName::DirExists()", "目录存在检查", "QDir::exists()", "std::filesystem::is_directory()", "功能完全等价"],
        ["文件和路径操作", "wxDir", "目录操作", "QDir\nQDirIterator", "std::filesystem::directory_iterator", "现代C++更简洁"],
        ["文件和路径操作", "wxStandardPaths", "标准系统路径", "QStandardPaths", "平台特定API", "Qt抽象层更好"],
        ["文件和路径操作", "wxFile", "文件读写", "QFile", "std::fstream\nFILE*", "Qt提供更多便利"],
        ["文件和路径操作", "wxTextFile", "文本文件操作", "QTextStream + QFile", "std::ifstream\nstd::ofstream", "STL更标准"],
        
        # 3. 时间和日期功能
        ["时间和日期功能", "wxDateTime", "日期时间类", "QDateTime", "std::chrono::system_clock\nstd::chrono::time_point", "现代C++性能更好"],
        ["时间和日期功能", "wxDateTime::Now()", "获取当前时间", "QDateTime::currentDateTime()", "std::chrono::system_clock::now()", "STL版本零依赖"],
        ["时间和日期功能", "wxDateTime::FormatISOCombined()", "ISO格式化", "QDateTime::toString(Qt::ISODate)", "std::chrono::format() (C++20)\nstrftime()", "Qt格式化更丰富"],
        ["时间和日期功能", "wxTimer", "定时器", "QTimer", "std::chrono + 线程\nboost::asio::deadline_timer", "Qt事件循环集成"],
        ["时间和日期功能", "wxTimerEvent", "定时器事件", "QTimer::timeout() 信号", "回调函数\nstd::function", "Qt信号槽更优雅"],
        ["时间和日期功能", "wxStopWatch", "秒表计时", "QElapsedTimer", "std::chrono::steady_clock", "精度相当"],
        
        # 4. 几何和数学
        ["几何和数学", "wxPoint", "2D整数坐标", "QPoint", "struct Point { int x, y; }", "功能完全等价"],
        ["几何和数学", "wxRealPoint", "2D浮点坐标", "QPointF", "struct PointF { double x, y; }", "Qt版本功能更丰富"],
        ["几何和数学", "wxPoint2D", "高精度2D坐标", "QPointF", "glm::vec2", "GLM专业数学库"],
        ["几何和数学", "wxSize", "尺寸", "QSize", "struct Size { int width, height; }", "简单结构体足够"],
        ["几何和数学", "wxRect", "矩形", "QRect", "struct Rect { int x, y, w, h; }", "Qt几何操作更丰富"],
        ["几何和数学", "wxRegion", "复杂区域", "QRegion", "自定义几何库", "Qt集成度更好"],
        ["几何和数学", "wxCoord", "坐标类型", "qreal\nint", "int\ndouble", "类型别名"],
        
        # 5. 容器和集合
        ["容器和集合", "wxArrayString", "字符串数组", "QStringList", "std::vector<std::string>", "Qt字符串操作更丰富"],
        ["容器和集合", "wxArrayInt", "整数数组", "QList<int>\nQVector<int>", "std::vector<int>", "STL性能更好"],
        ["容器和集合", "wxList", "链表", "QLinkedList\nQList", "std::list", "STL更标准"],
        ["容器和集合", "wxObjectList", "对象链表", "QList<QObject*>", "std::list<std::shared_ptr<T>>", "现代C++内存安全"],
        ["容器和集合", "wxHashMap", "哈希映射", "QHash\nQMap", "std::unordered_map", "STL性能优秀"],
        ["容器和集合", "wxHashSet", "哈希集合", "QSet", "std::unordered_set", "功能等价"],
        ["容器和集合", "wxSortedArray", "排序数组", "QMap", "std::set\nstd::map", "STL算法复杂度保证"],
        
        # 6. 流和序列化
        ["流和序列化", "wxInputStream", "输入流基类", "QIODevice", "std::istream", "STL更标准"],
        ["流和序列化", "wxOutputStream", "输出流基类", "QIODevice", "std::ostream", "STL兼容性更好"],
        ["流和序列化", "wxFileInputStream", "文件输入流", "QFile", "std::ifstream", "功能相当"],
        ["流和序列化", "wxFileOutputStream", "文件输出流", "QFile", "std::ofstream", "性能相近"],
        ["流和序列化", "wxMemoryInputStream", "内存输入流", "QBuffer", "std::istringstream", "Qt缓冲区管理更好"],
        ["流和序列化", "wxMemoryOutputStream", "内存输出流", "QBuffer", "std::ostringstream", "内存管理自动化"],
        ["流和序列化", "wxTextInputStream", "文本输入流", "QTextStream", "std::istream", "Qt编码处理更好"],
        ["流和序列化", "wxTextOutputStream", "文本输出流", "QTextStream", "std::ostream", "Qt国际化支持"],
        ["流和序列化", "wxDataInputStream", "数据输入流", "QDataStream", "二进制序列化库", "Qt类型安全"],
        ["流和序列化", "wxDataOutputStream", "数据输出流", "QDataStream", "二进制序列化库", "跨平台兼容"],
        ["流和序列化", "wxStreamBuffer", "流缓冲区", "QIODevice", "std::streambuf", "底层控制"],
        
        # 7. 压缩和归档
        ["压缩和归档", "wxZipInputStream", "ZIP输入流", "第三方: QuaZip", "libzip\nminizip\nzlib", "专业库功能更强"],
        ["压缩和归档", "wxZipOutputStream", "ZIP输出流", "第三方: QuaZip", "libzip\nminizip", "性能优化"],
        ["压缩和归档", "wxZipEntry", "ZIP条目信息", "QuaZipFileInfo", "zip_stat_t (libzip)", "元数据处理"],
        ["压缩和归档", "wxArchiveEntry", "通用归档接口", "抽象接口", "自定义接口", "接口设计"],
        
        # 8. 网络和通信
        ["网络和通信", "wxSocket", "Socket基类", "QTcpSocket\nQUdpSocket", "boost::asio\nPOSIX sockets", "boost::asio性能更好"],
        ["网络和通信", "wxSocketBase", "Socket基础功能", "QAbstractSocket", "Berkeley sockets", "Qt抽象更好"],
        ["网络和通信", "wxURL", "URL解析访问", "QUrl", "curl\nboost::beast", "Qt解析更完整"],
        ["网络和通信", "wxURI", "URI解析", "QUrl", "uriparser库", "专业库更严格"],
        
        # 9. 多线程和并发
        ["多线程和并发", "wxThread", "线程类", "QThread", "std::thread", "现代C++更标准"],
        ["多线程和并发", "wxThreadEvent", "线程事件", "Qt信号槽机制\nQEvent", "std::condition_variable\n自定义事件系统", "Qt事件系统更强"],
        ["多线程和并发", "wxCriticalSection", "临界区", "QMutex", "std::mutex", "功能等价"],
        ["多线程和并发", "wxMutex", "互斥锁", "QMutex", "std::mutex", "性能相当"],
        ["多线程和并发", "wxSemaphore", "信号量", "QSemaphore", "std::counting_semaphore (C++20)\nPOSIX semaphore", "现代C++更标准"],
        ["多线程和并发", "wxCondition", "条件变量", "QWaitCondition", "std::condition_variable", "STL更通用"],
        
        # 10. XML处理
        ["XML处理", "wxXmlDocument", "XML文档", "QDomDocument\nQXmlStreamReader", "pugixml\ntinyxml2\nlibxml2", "pugixml性能更好"],
        ["XML处理", "wxXmlNode", "XML节点", "QDomNode\nQDomElement", "pugi::xml_node", "专业库API更简洁"],
        
        # 11. 配置和设置
        ["配置和设置", "wxConfigBase", "配置基类", "QSettings", "nlohmann/json\ntoml++\nlibconfig++", "JSON格式更现代"],
        ["配置和设置", "wxConfig", "通用配置", "QSettings", "平台特定注册表/配置文件", "Qt跨平台更好"],
        ["配置和设置", "wxFileConfig", "文件配置", "QSettings (INI格式)", "INI解析库", "格式标准化"],
        ["配置和设置", "wxRegConfig", "注册表配置", "QSettings (Windows注册表)", "Windows Registry API", "平台特定优化"],
        
        # 12. 系统集成
        ["系统集成", "wxSystemSettings", "系统设置获取", "QStyleHints\nQPalette", "平台特定API", "Qt抽象层更完整"],
        ["系统集成", "wxSystemAppearance", "系统外观", "QStyleHints::colorScheme()", "平台主题检测API", "现代主题支持"],
        ["系统集成", "wxPlatformInfo", "平台信息", "QSysInfo", "uname()\nGetVersionEx()", "Qt信息更丰富"],
        ["系统集成", "wxOperatingSystemId", "操作系统识别", "QSysInfo::productType()", "编译时宏定义", "编译时确定更高效"],
        
        # 13. 日志系统
        ["日志系统", "wxLogTrace()", "跟踪日志", "qDebug()", "spdlog\nglog\nfmt::print()", "spdlog性能最佳"],
        ["日志系统", "wxLogMessage()", "信息日志", "qInfo()", "std::cout", "简单场景用STL"],
        ["日志系统", "wxLogError()", "错误日志", "qCritical()", "std::cerr", "标准错误流"],
        ["日志系统", "wxLogWarning()", "警告日志", "qWarning()", "std::cerr", "统一错误处理"],
        ["日志系统", "wxLogDebug()", "调试日志", "qDebug()", "条件编译的调试输出", "发布版本可移除"],
        ["日志系统", "wxLogVerbose()", "详细日志", "qInfo()", "详细模式输出", "运行时控制"],
        ["日志系统", "wxLogNull", "禁用日志", "临时禁用Qt日志", "日志级别控制", "配置化管理"],
        
        # 14. 进程和执行
        ["进程和执行", "wxExecute()", "执行外部程序", "QProcess::execute()", "std::system()\nfork()+exec() (Unix)\nCreateProcess() (Windows)", "Qt进程管理更完整"],
        ["进程和执行", "wxProcess", "进程控制", "QProcess", "平台特定进程API", "Qt封装更友好"],
        
        # 15. 剪贴板和数据传输
        ["剪贴板和数据传输", "wxClipboard", "剪贴板访问", "QClipboard", "平台特定剪贴板API", "Qt多格式支持更好"],
        ["剪贴板和数据传输", "wxDropTarget", "拖拽目标", "QWidget::dropEvent()", "平台特定拖拽API", "Qt事件集成"],
        ["剪贴板和数据传输", "wxDropSource", "拖拽源", "QDrag", "平台特定拖拽API", "Qt拖拽效果更丰富"],
        ["剪贴板和数据传输", "wxDataObject", "数据对象", "QMimeData", "自定义数据格式", "Qt MIME类型支持"],
        
        # 16. 应用程序框架
        ["应用程序框架", "wxApp", "GUI应用程序", "QApplication", "自定义应用程序类", "Qt框架更完整"],
        ["应用程序框架", "wxAppConsole", "控制台应用程序", "QCoreApplication", "main() 函数", "简单程序用main"],
        ["应用程序框架", "wxCmdLineParser", "命令行解析", "QCommandLineParser", "getopt()\nargparse\nCLI11\nboost::program_options", "专业库功能更强"],
        ["应用程序框架", "wxCmdLineEntryDesc", "命令行参数描述", "QCommandLineOption", "自定义参数描述结构", "类型安全"],
        
        # 17. 调试和断言
        ["调试和断言", "wxASSERT()", "运行时断言", "Q_ASSERT()", "assert()\n自定义断言宏", "标准assert更通用"],
        ["调试和断言", "wxCHECK_MSG()", "带消息的检查", "Q_ASSERT_X()", "自定义检查宏", "自定义更灵活"],
        
        # 18. 单实例管理
        ["单实例管理", "wxSingleInstanceChecker", "单实例检查", "QLockFile\nQSharedMemory", "文件锁\n命名管道\n网络端口检查", "文件锁最简单"],
        
        # 19. 事件系统
        ["事件系统", "wxDEFINE_EVENT()", "事件定义", "Q_DECLARE_METATYPE\n自定义信号", "观察者模式\nstd::function回调", "现代C++回调更灵活"],
        ["事件系统", "wxDECLARE_EVENT()", "事件声明", "信号声明", "事件接口声明", "接口设计"],
        
        # 20. 媒体和MIME
        ["媒体和MIME", "wxMimeTypesManager", "MIME类型管理", "QMimeDatabase", "libmagic\n平台特定MIME API", "libmagic检测更准确"],
        
        # 21. 输入验证
        ["输入验证", "wxTextValidator", "输入验证", "QValidator\nQRegExpValidator", "std::regex\n自定义验证函数", "正则表达式更灵活"],
        
        # 22. 国际化
        ["国际化", "wxTranslation", "翻译管理", "QTranslator", "gettext\nICU库", "gettext工具链更成熟"],
        ["国际化", "wxLocale", "本地化设置", "QLocale", "std::locale\nICU库", "ICU功能最完整"],
        
        # 23. 正则表达式
        ["正则表达式", "wxRegEx", "正则表达式", "QRegularExpression", "std::regex", "STL更标准"],
        
        # 24. 常用宏和常量
        ["常用宏和常量", "wxEmptyString", "空字符串", "QString()", "std::string()", "简单常量"],
        ["常用宏和常量", "wxDefaultPosition", "默认位置", "QPoint(-1, -1)", "{-1, -1}", "常量定义"],
        ["常用宏和常量", "wxDefaultSize", "默认尺寸", "QSize(-1, -1)", "{-1, -1}", "结构体初始化"],
        ["常用宏和常量", "wxID_ANY", "任意ID", "-1", "-1", "简单整数"],
    ]
    
    # 创建DataFrame
    df = pd.DataFrame(data, columns=[
        "功能类别", "wxWidgets元素", "功能描述", "Qt替代方案", "STL/其他替代方案", "推荐理由"
    ])
    
    # 创建Excel工作簿
    wb = Workbook()
    ws = wb.active
    ws.title = "wxWidgets替换方案"
    
    # 添加标题行
    headers = ["功能类别", "wxWidgets元素", "功能描述", "Qt替代方案", "STL/其他替代方案", "推荐理由"]
    ws.append(headers)
    
    # 添加数据
    for row in data:
        ws.append(row)
    
    # 设置样式
    # 标题行样式
    header_fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
    header_font = Font(color="FFFFFF", bold=True)
    
    for cell in ws[1]:
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal="center", vertical="center")
    
    # 数据行样式
    thin_border = Border(
        left=Side(style='thin'),
        right=Side(style='thin'),
        top=Side(style='thin'),
        bottom=Side(style='thin')
    )
    
    # 分类颜色
    category_colors = {
        "字符串和数据类型": "E8F4FD",
        "文件和路径操作": "FFF2CC",
        "时间和日期功能": "E8F5E8",
        "几何和数学": "F4E8FF",
        "容器和集合": "FFE8E8",
        "流和序列化": "E8FFE8",
        "压缩和归档": "FFE8CC",
        "网络和通信": "E8E8FF",
        "多线程和并发": "F0F0F0",
        "XML处理": "FFCCCC",
        "配置和设置": "CCFFCC",
        "系统集成": "CCCCFF",
        "日志系统": "FFCC99",
        "进程和执行": "CC99FF",
        "剪贴板和数据传输": "99FFCC",
        "应用程序框架": "FF99CC",
        "调试和断言": "CCFF99",
        "单实例管理": "99CCFF",
        "事件系统": "FFCCFF",
        "媒体和MIME": "CCFFFF",
        "输入验证": "FFFFCC",
        "国际化": "FFFF99",
        "正则表达式": "CCCC99",
        "常用宏和常量": "99CC99"
    }
    
    # 应用样式到数据行
    for row_idx, row in enumerate(ws.iter_rows(min_row=2), start=2):
        category = row[0].value
        fill_color = category_colors.get(category, "FFFFFF")
        fill = PatternFill(start_color=fill_color, end_color=fill_color, fill_type="solid")
        
        for cell in row:
            cell.border = thin_border
            cell.alignment = Alignment(horizontal="left", vertical="top", wrap_text=True)
            cell.fill = fill
    
    # 调整列宽
    column_widths = [20, 30, 25, 35, 40, 25]
    for idx, width in enumerate(column_widths, 1):
        ws.column_dimensions[ws.cell(row=1, column=idx).column_letter].width = width
    
    # 调整行高
    for row in ws.iter_rows():
        ws.row_dimensions[row[0].row].height = 30
    
    # 冻结首行
    ws.freeze_panes = "A2"
    
    # 添加筛选
    ws.auto_filter.ref = f"A1:{ws.cell(row=ws.max_row, column=ws.max_column).coordinate}"
    
    # 保存文件
    filename = "wxWidgets_replacement_mapping.xlsx"
    wb.save(filename)
    print(f"Excel文件已生成: {filename}")
    
    # 生成统计信息
    print(f"\n统计信息:")
    print(f"总功能类别: {len(df['功能类别'].unique())}")
    print(f"总wx元素: {len(df)}")
    
    category_counts = df['功能类别'].value_counts()
    print(f"\n各类别元素数量:")
    for category, count in category_counts.items():
        print(f"  {category}: {count}")

if __name__ == "__main__":
    try:
        create_wx_replacement_excel()
    except ImportError as e:
        print("需要安装依赖库:")
        print("pip install pandas openpyxl")
        print(f"错误: {e}")
    except Exception as e:
        print(f"生成Excel文件时出错: {e}")