#!/usr/bin/env python3
"""
统计当前目录及子目录下所有C++代码文件的数量
"""

import os
from pathlib import Path

def count_cpp_files(directory="."):
    """统计指定目录下的C++文件数量"""
    
    # C++相关的文件扩展名
    cpp_extensions = {'.cpp', '.cc', '.cxx', '.c++', '.h', '.hpp', '.hxx', '.h++', '.ipp', '.inl'}
    
    # 统计变量
    file_counts = {}
    total_count = 0
    
    # 遍历目录
    for root, dirs, files in os.walk(directory):
        for file in files:
            # 获取文件扩展名
            ext = Path(file).suffix.lower()
            
            if ext in cpp_extensions:
                # 统计每种扩展名的数量
                if ext not in file_counts:
                    file_counts[ext] = 0
                file_counts[ext] += 1
                total_count += 1
    
    return file_counts, total_count

def main():
    print("正在统计C++代码文件...")
    print("=" * 50)
    
    # 统计当前目录
    file_counts, total = count_cpp_files(".")
    
    # 按扩展名显示统计结果
    print("\n按扩展名分类统计:")
    print("-" * 30)
    
    # 按数量降序排序
    sorted_counts = sorted(file_counts.items(), key=lambda x: x[1], reverse=True)
    
    for ext, count in sorted_counts:
        print(f"{ext:8s}: {count:6d} 个文件")
    
    print("-" * 30)
    print(f"总计: {total} 个C++代码文件")
    
    # 统计一些额外信息
    header_files = sum(count for ext, count in file_counts.items() 
                      if ext in {'.h', '.hpp', '.hxx', '.h++'})
    source_files = sum(count for ext, count in file_counts.items() 
                      if ext in {'.cpp', '.cc', '.cxx', '.c++'})
    
    print("\n分类统计:")
    print(f"头文件: {header_files} 个")
    print(f"源文件: {source_files} 个")
    
    if header_files > 0 and source_files > 0:
        ratio = header_files / source_files
        print(f"头文件/源文件比例: {ratio:.2f}")

if __name__ == "__main__":
    main()