#!/usr/bin/env python3
"""
直接扫描源码并生成wx非UI元素统计Excel表格
首页统计每个wx元素出现的次数，每行一个元素，并添加链接跳转到详细页面
详细页面包含文件路径和具体的行号信息
"""

import os
import re
import time
from pathlib import Path
from collections import defaultdict, Counter
from typing import Dict, List, Tuple
import openpyxl
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter


class WxElementsDirectToExcel:
    def __init__(self, source_dir: str):
        self.source_dir = Path(source_dir)
        self.element_details = defaultdict(list)  # 元素名 -> [(文件路径, 行号, 代码行), ...]
        self.element_counts = Counter()  # 元素名 -> 总出现次数
        
        # 定义要搜索的wx关键字模式（非UI相关）
        self.wx_patterns = {
            # 基础数据类型
            'basic_types': [
                r'\bwxString\b',
                r'\bwxArrayString\b', 
                r'\bwxFileName\b',
                r'\bwxVariant\b',
                r'\bwxAny\b',
                r'\bwxBase64\w*\b'
            ],
            
            # 几何和数学
            'geometry': [
                r'\bwxPoint\b',
                r'\bwxRealPoint\b',
                r'\bwxPoint2D\b',
                r'\bwxSize\b',
                r'\bwxRect\b',
                r'\bwxRegion\b',
                r'\bwxCoord\b'
            ],
            
            # 时间和定时器
            'time': [
                r'\bwxDateTime\b',
                r'\bwxTimer\b',
                r'\bwxTimerEvent\b',
                r'\bwxStopWatch\b',
                r'\bwxGetLocalTime\b'
            ],
            
            # 文件和路径
            'file_path': [
                r'\bwxDir\b',
                r'\bwxFile\b',
                r'\bwxTextFile\b',
                r'\bwxStandardPaths\b'
            ],
            
            # 容器和集合
            'containers': [
                r'\bwxArrayInt\b',
                r'\bwxList\b',
                r'\bwxObjectList\b',
                r'\bwxHashMap\b',
                r'\bwxHashSet\b',
                r'\bwxSortedArray\b'
            ],
            
            # 流和序列化
            'streams': [
                r'\bwxInputStream\b',
                r'\bwxOutputStream\b',
                r'\bwxFileInputStream\b',
                r'\bwxFileOutputStream\b',
                r'\bwxMemoryInputStream\b',
                r'\bwxMemoryOutputStream\b',
                r'\bwxTextInputStream\b',
                r'\bwxTextOutputStream\b',
                r'\bwxDataInputStream\b',
                r'\bwxDataOutputStream\b',
                r'\bwxStreamBuffer\b'
            ],
            
            # 压缩和归档
            'archive': [
                r'\bwxZipInputStream\b',
                r'\bwxZipOutputStream\b',
                r'\bwxZipEntry\b',
                r'\bwxArchiveEntry\b'
            ],
            
            # 网络和通信
            'network': [
                r'\bwxSocket\b',
                r'\bwxSocketBase\b',
                r'\bwxURL\b',
                r'\bwxURI\b'
            ],
            
            # 多线程
            'threading': [
                r'\bwxThread\b',
                r'\bwxThreadEvent\b',
                r'\bwxCriticalSection\b',
                r'\bwxMutex\b',
                r'\bwxSemaphore\b',
                r'\bwxCondition\b'
            ],
            
            # XML处理
            'xml': [
                r'\bwxXmlDocument\b',
                r'\bwxXmlNode\b'
            ],
            
            # 配置管理
            'config': [
                r'\bwxConfig\b',
                r'\bwxConfigBase\b',
                r'\bwxFileConfig\b',
                r'\bwxRegConfig\b'
            ],
            
            # 系统集成
            'system': [
                r'\bwxSystemSettings\b',
                r'\bwxSystemAppearance\b',
                r'\bwxPlatformInfo\b',
                r'\bwxOperatingSystemId\b'
            ],
            
            # 日志系统
            'logging': [
                r'\bwxLogTrace\b',
                r'\bwxLogMessage\b',
                r'\bwxLogError\b',
                r'\bwxLogWarning\b',
                r'\bwxLogDebug\b',
                r'\bwxLogVerbose\b',
                r'\bwxLogNull\b'
            ],
            
            # 进程管理
            'process': [
                r'\bwxExecute\b',
                r'\bwxProcess\b'
            ],
            
            # 剪贴板和拖拽
            'clipboard': [
                r'\bwxClipboard\b',
                r'\bwxDropTarget\b',
                r'\bwxDropSource\b',
                r'\bwxDataObject\b'
            ],
            
            # 应用程序框架
            'app_framework': [
                r'\bwxApp\b',
                r'\bwxAppConsole\b',
                r'\bwxCmdLineParser\b',
                r'\bwxCmdLineEntryDesc\b'
            ],
            
            # 调试支持
            'debug': [
                r'\bwxASSERT\b',
                r'\bwxCHECK_MSG\b'
            ],
            
            # 单实例管理
            'singleton': [
                r'\bwxSingleInstanceChecker\b'
            ],
            
            # 事件系统
            'events': [
                r'\bwxDEFINE_EVENT\b',
                r'\bwxDECLARE_EVENT\b',
                r'\bwxEVT_\w+\b'
            ],
            
            # MIME和媒体
            'mime': [
                r'\bwxMimeTypesManager\b'
            ],
            
            # 验证器
            'validators': [
                r'\bwxTextValidator\b'
            ],
            
            # 国际化
            'i18n': [
                r'\bwxTranslation\b',
                r'\bwxLocale\b'
            ],
            
            # 正则表达式
            'regex': [
                r'\bwxRegEx\b'
            ],
            
            # 常用宏和常量
            'macros': [
                r'\bwxEmptyString\b',
                r'\bwxDefaultPosition\b',
                r'\bwxDefaultSize\b',
                r'\bwxID_ANY\b',
                r'\bwxFileSelectorDefaultWildcardStr\b',
                r'\bBEGIN_EVENT_TABLE\b',
                r'\bEND_EVENT_TABLE\b'
            ]
        }
        
        # 文件扩展名过滤
        self.file_extensions = {'.cpp', '.h', '.hpp', '.cc', '.cxx', '.c'}
        
        # 排除的目录
        self.exclude_dirs = {'.git', 'build', 'cmake', 'Documentation', 'demos', 'resources'}
        
        # 类别映射
        self.category_mapping = self._build_category_mapping()
    
    def _build_category_mapping(self):
        """构建wx元素到类别的映射"""
        element_to_category = {}
        for category, patterns in self.wx_patterns.items():
            for pattern in patterns:
                # 提取实际的元素名称（去掉正则表达式符号）
                element_name = pattern.replace(r'\b', '').replace(r'\w*', '').replace(r'\w+', '')
                element_to_category[element_name] = category
        return element_to_category
    
    def should_process_file(self, file_path: Path) -> bool:
        """判断是否应该处理该文件"""
        # 检查文件扩展名
        if file_path.suffix.lower() not in self.file_extensions:
            return False
            
        # 检查是否在排除目录中
        for part in file_path.parts:
            if part in self.exclude_dirs:
                return False
                
        return True
    
    def search_in_file(self, file_path: Path) -> None:
        """在单个文件中搜索wx模式，直接更新统计信息"""
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                lines = f.readlines()
                
            rel_path = str(file_path.relative_to(self.source_dir))
            
            for line_num, line in enumerate(lines, 1):
                for category, patterns in self.wx_patterns.items():
                    for pattern in patterns:
                        matches = re.findall(pattern, line)
                        for match in matches:
                            # 统计元素出现次数
                            self.element_counts[match] += 1
                            
                            # 记录详细信息（文件路径、行号、代码行）
                            self.element_details[match].append((rel_path, line_num, line.strip()))
                            
        except Exception as e:
            print(f"Error reading {file_path}: {e}")
    
    def scan_directory(self) -> None:
        """扫描整个目录"""
        print(f"Scanning directory: {self.source_dir}")
        
        # 统计总文件数
        all_files = [f for f in self.source_dir.rglob('*') 
                     if f.is_file() and self.should_process_file(f)]
        total_files = len(all_files)
        print(f"Found {total_files} files to process")
        
        start_time = time.time()
        file_count = 0
        
        for file_path in all_files:
            file_count += 1
            
            # 进度显示
            if file_count % 100 == 0:
                elapsed = time.time() - start_time
                progress = (file_count / total_files) * 100
                speed = file_count / elapsed if elapsed > 0 else 0
                eta = (total_files - file_count) / speed if speed > 0 else 0
                print(f"Progress: {file_count}/{total_files} ({progress:.1f}%) "
                      f"Speed: {speed:.1f} files/s ETA: {eta:.0f}s")
            
            self.search_in_file(file_path)
        
        elapsed = time.time() - start_time
        print(f"\nCompleted scanning {file_count} files in {elapsed:.1f} seconds")
        print(f"Found {len(self.element_counts)} unique wx elements")
        print(f"Total occurrences: {sum(self.element_counts.values())}")
    
    def get_element_category(self, element: str) -> str:
        """获取元素的类别"""
        # 直接匹配
        if element in self.category_mapping:
            return self.category_mapping[element]
        
        # 模糊匹配 - 处理wxEVT_开头的事件
        if element.startswith('wxEVT_'):
            return 'events'
        
        # 其他模糊匹配规则
        for category_element, category in self.category_mapping.items():
            if category_element in element:
                return category
        
        return 'others'  # 未分类
    
    def create_excel_report(self, output_file: str):
        """创建Excel报告"""
        print(f"Creating Excel report: {output_file}")
        
        wb = Workbook()
        
        # 创建统计汇总页面
        self._create_summary_sheet(wb)
        
        # 为每个wx元素创建详细页面
        self._create_detail_sheets(wb)
        
        # 删除默认的空白工作表
        if 'Sheet' in wb.sheetnames:
            wb.remove(wb['Sheet'])
        
        # 保存工作簿
        wb.save(output_file)
        print(f"Excel report saved to: {output_file}")
    
    def _create_summary_sheet(self, wb: Workbook):
        """创建统计汇总页面"""
        ws = wb.active
        ws.title = "WX元素统计"
        
        # 设置标题样式
        title_font = Font(name='Microsoft YaHei', size=14, bold=True)
        header_font = Font(name='Microsoft YaHei', size=11, bold=True, color='FFFFFF')
        cell_font = Font(name='Microsoft YaHei', size=10)
        
        header_fill = PatternFill(start_color='366092', end_color='366092', fill_type='solid')
        center_alignment = Alignment(horizontal='center', vertical='center')
        
        # 设置标题
        ws.merge_cells('A1:E1')
        ws['A1'] = 'KiCad项目wx非UI元素使用统计（包含行号）'
        ws['A1'].font = title_font
        ws['A1'].alignment = center_alignment
        
        # 设置表头
        headers = ['序号', 'wx元素', '类别', '出现次数', '详细信息']
        for col, header in enumerate(headers, 1):
            cell = ws.cell(row=3, column=col, value=header)
            cell.font = header_font
            cell.fill = header_fill
            cell.alignment = center_alignment
        
        # 按出现次数排序的wx元素
        sorted_elements = sorted(self.element_counts.items(), key=lambda x: x[1], reverse=True)
        
        # 填充数据
        for row, (element, count) in enumerate(sorted_elements, 4):
            category = self.get_element_category(element)
            
            # 统计该元素涉及的文件数
            files = set(detail[0] for detail in self.element_details[element])
            file_count = len(files)
            
            ws.cell(row=row, column=1, value=row-3).font = cell_font  # 序号
            ws.cell(row=row, column=2, value=element).font = cell_font  # wx元素
            ws.cell(row=row, column=3, value=category).font = cell_font  # 类别
            ws.cell(row=row, column=4, value=count).font = cell_font  # 出现次数
            
            # 创建到详细页面的超链接
            detail_cell = ws.cell(row=row, column=5, value=f"查看详情 ({file_count} 个文件)")
            detail_cell.font = Font(name='Microsoft YaHei', size=10, color='0000FF', underline='single')
            detail_cell.hyperlink = f"#{self._get_sheet_name(element)}!A1"
        
        # 调整列宽
        ws.column_dimensions['A'].width = 8
        ws.column_dimensions['B'].width = 25
        ws.column_dimensions['C'].width = 15
        ws.column_dimensions['D'].width = 12
        ws.column_dimensions['E'].width = 25
        
        # 添加统计信息
        total_elements = len(self.element_counts)
        total_occurrences = sum(self.element_counts.values())
        total_files = len(set(detail[0] for details in self.element_details.values() for detail in details))
        
        info_row = len(sorted_elements) + 6
        ws.cell(row=info_row, column=1, value=f"统计信息：").font = Font(name='Microsoft YaHei', size=11, bold=True)
        ws.cell(row=info_row+1, column=1, value=f"• 不重复的wx元素数量: {total_elements}").font = cell_font
        ws.cell(row=info_row+2, column=1, value=f"• wx元素总出现次数: {total_occurrences}").font = cell_font
        ws.cell(row=info_row+3, column=1, value=f"• 涉及的文件数量: {total_files}").font = cell_font
    
    def _create_detail_sheets(self, wb: Workbook):
        """为每个wx元素创建详细页面"""
        header_font = Font(name='Microsoft YaHei', size=11, bold=True, color='FFFFFF')
        cell_font = Font(name='Microsoft YaHei', size=10)
        header_fill = PatternFill(start_color='366092', end_color='366092', fill_type='solid')
        center_alignment = Alignment(horizontal='center', vertical='center')
        
        for element in sorted(self.element_details.keys()):
            # 创建工作表
            sheet_name = self._get_sheet_name(element)
            ws = wb.create_sheet(title=sheet_name)
            
            # 设置标题
            ws.merge_cells('A1:E1')
            ws['A1'] = f'wx元素详情: {element}'
            ws['A1'].font = Font(name='Microsoft YaHei', size=14, bold=True)
            ws['A1'].alignment = center_alignment
            
            # 设置统计信息
            category = self.get_element_category(element)
            count = self.element_counts[element]
            files = set(detail[0] for detail in self.element_details[element])
            file_count = len(files)
            
            ws['A2'] = f'类别: {category}'
            ws['A3'] = f'总出现次数: {count}'
            ws['A4'] = f'涉及文件数: {file_count}'
            
            # 设置表头
            headers = ['序号', '文件路径', '文件名', '行号', '代码内容']
            for col, header in enumerate(headers, 1):
                cell = ws.cell(row=6, column=col, value=header)
                cell.font = header_font
                cell.fill = header_fill
                cell.alignment = center_alignment
            
            # 按文件路径和行号排序
            sorted_details = sorted(self.element_details[element], key=lambda x: (x[0], x[1]))
            
            # 填充详细数据
            for row, (file_path, line_num, code_line) in enumerate(sorted_details, 7):
                ws.cell(row=row, column=1, value=row-6).font = cell_font  # 序号
                ws.cell(row=row, column=2, value=file_path).font = cell_font  # 文件路径
                
                # 提取文件名
                file_name = Path(file_path).name
                ws.cell(row=row, column=3, value=file_name).font = cell_font  # 文件名
                
                ws.cell(row=row, column=4, value=line_num).font = cell_font  # 行号
                
                # 截断过长的代码行
                if len(code_line) > 100:
                    code_line = code_line[:97] + "..."
                ws.cell(row=row, column=5, value=code_line).font = cell_font  # 代码内容
            
            # 调整列宽
            ws.column_dimensions['A'].width = 8
            ws.column_dimensions['B'].width = 60
            ws.column_dimensions['C'].width = 25
            ws.column_dimensions['D'].width = 8
            ws.column_dimensions['E'].width = 50
            
            # 添加返回汇总页的链接
            back_row = len(sorted_details) + 9
            back_cell = ws.cell(row=back_row, column=1, value="← 返回汇总页")
            back_cell.font = Font(name='Microsoft YaHei', size=10, color='0000FF', underline='single')
            back_cell.hyperlink = "#WX元素统计!A1"
    
    def _get_sheet_name(self, element: str) -> str:
        """生成合法的工作表名称（Excel工作表名称有长度和字符限制）"""
        # Excel工作表名称限制：最长31个字符，不能包含: \ / ? * [ ]
        safe_name = element.replace('\\', '_').replace('/', '_').replace('?', '_').replace('*', '_').replace('[', '_').replace(']', '_')
        if len(safe_name) > 31:
            safe_name = safe_name[:28] + "..."
        return safe_name


def main():
    """主函数"""
    # 配置路径
    source_dir = ".."  # KiCad源码根目录
    output_file = "wx_elements_statistics_final.xlsx"
    
    print("KiCad wx非UI元素统计分析")
    print("=" * 50)
    
    # 创建分析器
    analyzer = WxElementsDirectToExcel(source_dir)
    
    # 扫描目录
    analyzer.scan_directory()
    
    # 生成Excel报告
    analyzer.create_excel_report(output_file)
    
    print(f"\nExcel报告生成完成!")
    print(f"统计汇总: {len(analyzer.element_counts)} 个不重复的wx元素")
    print(f"总出现次数: {sum(analyzer.element_counts.values())}")
    print(f"输出文件: {output_file}")
    print(f"打开Excel文件查看详细的wx元素使用统计，包含具体的文件和行号信息")


if __name__ == "__main__":
    main()