# KiCad wxWidgets 非UI功能替换映射表（含替代方案）

本文档列出了KiCad中使用的所有非UI相关的wxWidgets功能，为每个功能提供Qt和其他框架的替代方案。

## 1. 字符串和数据类型

### 核心字符串类型

| wxWidgets | Qt 替代方案 | STL/其他替代方案 | 说明 |
|-----------|-------------|------------------|------|
| `wxString` | `QString` | `std::string` (UTF-8)<br>`std::u16string` (UTF-16) | Unicode字符串处理 |
| `wxArrayString` | `QStringList` | `std::vector<std::string>` | 字符串数组 |
| `wxStringTokenize()` | `QString::split()` | `std::regex`<br>`boost::split()` | 字符串分词 |

### 数据容器

| wxWidgets | Qt 替代方案 | STL/其他替代方案 | 说明 |
|-----------|-------------|------------------|------|
| `wxVariant` | `QVariant` | `std::variant` (C++17)<br>`boost::variant` | 通用数据容器 |
| `wxAny` | `QVariant` | `std::any` (C++17)<br>`boost::any` | 类型擦除容器 |
| `wxBase64Encode/Decode()` | `QByteArray::toBase64()`<br>`QByteArray::fromBase64()` | `openssl/base64.h`<br>`boost::beast::detail::base64` | Base64编码解码 |

## 2. 文件和路径操作

### 文件路径处理

| wxWidgets | Qt 替代方案 | STL/其他替代方案 | 说明 |
|-----------|-------------|------------------|------|
| `wxFileName` | `QFileInfo`<br>`QDir` | `std::filesystem::path` (C++17)<br>`boost::filesystem::path` | 文件路径操作 |
| `wxFileName::Assign()` | `QFileInfo::setFile()` | `std::filesystem::path::assign()` | 路径赋值 |
| `wxFileName::GetFullPath()` | `QFileInfo::absoluteFilePath()` | `std::filesystem::absolute()` | 获取绝对路径 |
| `wxFileName::FileExists()` | `QFile::exists()` | `std::filesystem::exists()` | 文件存在检查 |
| `wxFileName::DirExists()` | `QDir::exists()` | `std::filesystem::is_directory()` | 目录存在检查 |
| `wxFileName::GetPathSeparator()` | `QDir::separator()` | `std::filesystem::path::preferred_separator` | 路径分隔符 |

### 目录操作

| wxWidgets | Qt 替代方案 | STL/其他替代方案 | 说明 |
|-----------|-------------|------------------|------|
| `wxDir` | `QDir`<br>`QDirIterator` | `std::filesystem::directory_iterator` | 目录操作 |
| `wxDir::Exists()` | `QDir::exists()` | `std::filesystem::exists()` | 目录存在检查 |
| `wxDir::GetFirst()`<br>`wxDir::GetNext()` | `QDirIterator::next()` | `std::filesystem::directory_iterator` | 目录遍历 |

### 标准路径

| wxWidgets | Qt 替代方案 | STL/其他替代方案 | 说明 |
|-----------|-------------|------------------|------|
| `wxStandardPaths` | `QStandardPaths` | 平台特定API:<br>Windows: `SHGetFolderPath`<br>Linux: `XDG_*` 环境变量<br>macOS: `NSSearchPathForDirectoriesInDomains` | 标准系统路径 |
| `wxStandardPaths::GetExecutablePath()` | `QCoreApplication::applicationFilePath()` | `/proc/self/exe` (Linux)<br>`GetModuleFileName` (Windows)<br>`_NSGetExecutablePath` (macOS) | 可执行文件路径 |

### 文件操作

| wxWidgets | Qt 替代方案 | STL/其他替代方案 | 说明 |
|-----------|-------------|------------------|------|
| `wxFile` | `QFile` | `std::fstream`<br>`FILE*` | 文件读写 |
| `wxTextFile` | `QTextStream` + `QFile` | `std::ifstream`<br>`std::ofstream` | 文本文件操作 |

## 3. 时间和日期功能

### 时间处理

| wxWidgets | Qt 替代方案 | STL/其他替代方案 | 说明 |
|-----------|-------------|------------------|------|
| `wxDateTime` | `QDateTime` | `std::chrono::system_clock`<br>`std::chrono::time_point` | 日期时间类 |
| `wxDateTime::Now()` | `QDateTime::currentDateTime()` | `std::chrono::system_clock::now()` | 获取当前时间 |
| `wxDateTime::FormatISOCombined()` | `QDateTime::toString(Qt::ISODate)` | `std::chrono::format()` (C++20)<br>`strftime()` | ISO格式化 |

### 定时器

| wxWidgets | Qt 替代方案 | STL/其他替代方案 | 说明 |
|-----------|-------------|------------------|------|
| `wxTimer` | `QTimer` | `std::chrono` + 线程<br>`boost::asio::deadline_timer` | 定时器 |
| `wxTimerEvent` | `QTimer::timeout()` 信号 | 回调函数<br>`std::function` | 定时器事件 |
| `wxStopWatch` | `QElapsedTimer` | `std::chrono::steady_clock` | 秒表计时 |

## 4. 几何和数学

### 基础几何类型

| wxWidgets | Qt 替代方案 | STL/其他替代方案 | 说明 |
|-----------|-------------|------------------|------|
| `wxPoint` | `QPoint` | `struct Point { int x, y; }` | 2D整数坐标 |
| `wxRealPoint` | `QPointF` | `struct PointF { double x, y; }` | 2D浮点坐标 |
| `wxPoint2D` | `QPointF` | GLM库: `glm::vec2` | 高精度2D坐标 |
| `wxSize` | `QSize` | `struct Size { int width, height; }` | 尺寸 |
| `wxRect` | `QRect` | `struct Rect { int x, y, w, h; }` | 矩形 |
| `wxRegion` | `QRegion` | 自定义几何库 | 复杂区域 |
| `wxCoord` | `qreal`<br>`int` | `int`<br>`double` | 坐标类型 |

## 5. 容器和集合

### 数组和列表

| wxWidgets | Qt 替代方案 | STL/其他替代方案 | 说明 |
|-----------|-------------|------------------|------|
| `wxArrayString` | `QStringList` | `std::vector<std::string>` | 字符串数组 |
| `wxArrayInt` | `QList<int>`<br>`QVector<int>` | `std::vector<int>` | 整数数组 |
| `wxList` | `QLinkedList`<br>`QList` | `std::list` | 链表 |
| `wxObjectList` | `QList<QObject*>` | `std::list<std::shared_ptr<T>>` | 对象链表 |
| `wxHashMap` | `QHash`<br>`QMap` | `std::unordered_map` | 哈希映射 |
| `wxHashSet` | `QSet` | `std::unordered_set` | 哈希集合 |
| `wxSortedArray` | `QMap` | `std::set`<br>`std::map` | 排序数组 |

## 6. 流和序列化

### 输入输出流

| wxWidgets | Qt 替代方案 | STL/其他替代方案 | 说明 |
|-----------|-------------|------------------|------|
| `wxInputStream` | `QIODevice` | `std::istream` | 输入流基类 |
| `wxOutputStream` | `QIODevice` | `std::ostream` | 输出流基类 |
| `wxFileInputStream` | `QFile` | `std::ifstream` | 文件输入流 |
| `wxFileOutputStream` | `QFile` | `std::ofstream` | 文件输出流 |
| `wxMemoryInputStream` | `QBuffer` | `std::istringstream` | 内存输入流 |
| `wxMemoryOutputStream` | `QBuffer` | `std::ostringstream` | 内存输出流 |
| `wxTextInputStream` | `QTextStream` | `std::istream` | 文本输入流 |
| `wxTextOutputStream` | `QTextStream` | `std::ostream` | 文本输出流 |
| `wxDataInputStream` | `QDataStream` | 二进制序列化库 | 数据输入流 |
| `wxDataOutputStream` | `QDataStream` | 二进制序列化库 | 数据输出流 |
| `wxStreamBuffer` | `QIODevice` | `std::streambuf` | 流缓冲区 |

## 7. 压缩和归档

### ZIP支持

| wxWidgets | Qt 替代方案 | STL/其他替代方案 | 说明 |
|-----------|-------------|------------------|------|
| `wxZipInputStream` | 第三方: `QuaZip` | `libzip`<br>`minizip`<br>`zlib` | ZIP输入流 |
| `wxZipOutputStream` | 第三方: `QuaZip` | `libzip`<br>`minizip` | ZIP输出流 |
| `wxZipEntry` | `QuaZipFileInfo` | `zip_stat_t` (libzip) | ZIP条目信息 |
| `wxArchiveEntry` | 抽象接口 | 自定义接口 | 通用归档接口 |

## 8. 网络和通信

### Socket通信

| wxWidgets | Qt 替代方案 | STL/其他替代方案 | 说明 |
|-----------|-------------|------------------|------|
| `wxSocket` | `QTcpSocket`<br>`QUdpSocket` | `boost::asio`<br>POSIX sockets | Socket基类 |
| `wxSocketBase` | `QAbstractSocket` | Berkeley sockets | Socket基础功能 |

### URL处理

| wxWidgets | Qt 替代方案 | STL/其他替代方案 | 说明 |
|-----------|-------------|------------------|------|
| `wxURL` | `QUrl` | `curl`<br>`boost::beast` | URL解析访问 |
| `wxURI` | `QUrl` | `uriparser`库 | URI解析 |

## 9. 多线程和并发

### 线程管理

| wxWidgets | Qt 替代方案 | STL/其他替代方案 | 说明 |
|-----------|-------------|------------------|------|
| `wxThread` | `QThread` | `std::thread` | 线程类 |
| `wxThreadEvent` | Qt信号槽机制<br>`QEvent` | `std::condition_variable`<br>自定义事件系统 | 线程事件 |

### 同步原语

| wxWidgets | Qt 替代方案 | STL/其他替代方案 | 说明 |
|-----------|-------------|------------------|------|
| `wxCriticalSection` | `QMutex` | `std::mutex` | 临界区 |
| `wxMutex` | `QMutex` | `std::mutex` | 互斥锁 |
| `wxSemaphore` | `QSemaphore` | `std::counting_semaphore` (C++20)<br>POSIX semaphore | 信号量 |
| `wxCondition` | `QWaitCondition` | `std::condition_variable` | 条件变量 |

## 10. XML处理

### XML解析

| wxWidgets | Qt 替代方案 | STL/其他替代方案 | 说明 |
|-----------|-------------|------------------|------|
| `wxXmlDocument` | `QDomDocument`<br>`QXmlStreamReader` | `pugixml`<br>`tinyxml2`<br>`libxml2` | XML文档 |
| `wxXmlNode` | `QDomNode`<br>`QDomElement` | `pugi::xml_node` | XML节点 |

## 11. 配置和设置

### 配置管理

| wxWidgets | Qt 替代方案 | STL/其他替代方案 | 说明 |
|-----------|-------------|------------------|------|
| `wxConfigBase` | `QSettings` | `nlohmann/json`<br>`toml++`<br>`libconfig++` | 配置基类 |
| `wxConfig` | `QSettings` | 平台特定注册表/配置文件 | 通用配置 |
| `wxFileConfig` | `QSettings` (INI格式) | INI解析库 | 文件配置 |
| `wxRegConfig` | `QSettings` (Windows注册表) | Windows Registry API | 注册表配置 |

## 12. 系统集成

### 系统设置

| wxWidgets | Qt 替代方案 | STL/其他替代方案 | 说明 |
|-----------|-------------|------------------|------|
| `wxSystemSettings` | `QStyleHints`<br>`QPalette` | 平台特定API | 系统设置获取 |
| `wxSystemAppearance` | `QStyleHints::colorScheme()` | 平台主题检测API | 系统外观 |
| `wxPlatformInfo` | `QSysInfo` | `uname()`<br>`GetVersionEx()` | 平台信息 |
| `wxOperatingSystemId` | `QSysInfo::productType()` | 编译时宏定义 | 操作系统识别 |

## 13. 日志系统

### 日志功能

| wxWidgets | Qt 替代方案 | STL/其他替代方案 | 说明 |
|-----------|-------------|------------------|------|
| `wxLogTrace()` | `qDebug()` | `spdlog`<br>`glog`<br>`fmt::print()` | 跟踪日志 |
| `wxLogMessage()` | `qInfo()` | `std::cout` | 信息日志 |
| `wxLogError()` | `qCritical()` | `std::cerr` | 错误日志 |
| `wxLogWarning()` | `qWarning()` | `std::cerr` | 警告日志 |
| `wxLogDebug()` | `qDebug()` | 条件编译的调试输出 | 调试日志 |
| `wxLogVerbose()` | `qInfo()` | 详细模式输出 | 详细日志 |
| `wxLogNull` | 临时禁用Qt日志 | 日志级别控制 | 禁用日志 |

## 14. 进程和执行

### 进程管理

| wxWidgets | Qt 替代方案 | STL/其他替代方案 | 说明 |
|-----------|-------------|------------------|------|
| `wxExecute()` | `QProcess::execute()` | `std::system()`<br>`fork()+exec()` (Unix)<br>`CreateProcess()` (Windows) | 执行外部程序 |
| `wxProcess` | `QProcess` | 平台特定进程API | 进程控制 |

## 15. 剪贴板和数据传输

### 剪贴板操作

| wxWidgets | Qt 替代方案 | STL/其他替代方案 | 说明 |
|-----------|-------------|------------------|------|
| `wxClipboard` | `QClipboard` | 平台特定剪贴板API | 剪贴板访问 |
| `wxDropTarget` | `QWidget::dropEvent()` | 平台特定拖拽API | 拖拽目标 |
| `wxDropSource` | `QDrag` | 平台特定拖拽API | 拖拽源 |
| `wxDataObject` | `QMimeData` | 自定义数据格式 | 数据对象 |

## 16. 应用程序框架

### 应用程序基类

| wxWidgets | Qt 替代方案 | STL/其他替代方案 | 说明 |
|-----------|-------------|------------------|------|
| `wxApp` | `QApplication` | 自定义应用程序类 | GUI应用程序 |
| `wxAppConsole` | `QCoreApplication` | `main()` 函数 | 控制台应用程序 |

### 命令行处理

| wxWidgets | Qt 替代方案 | STL/其他替代方案 | 说明 |
|-----------|-------------|------------------|------|
| `wxCmdLineParser` | `QCommandLineParser` | `getopt()`<br>`argparse` (Python风格)<br>`CLI11`<br>`boost::program_options` | 命令行解析 |
| `wxCmdLineEntryDesc` | `QCommandLineOption` | 自定义参数描述结构 | 命令行参数描述 |

## 17. 调试和断言

### 调试支持

| wxWidgets | Qt 替代方案 | STL/其他替代方案 | 说明 |
|-----------|-------------|------------------|------|
| `wxASSERT()` | `Q_ASSERT()` | `assert()`<br>自定义断言宏 | 运行时断言 |
| `wxCHECK_MSG()` | `Q_ASSERT_X()` | 自定义检查宏 | 带消息的检查 |

## 18. 单实例管理

### 单实例检查

| wxWidgets | Qt 替代方案 | STL/其他替代方案 | 说明 |
|-----------|-------------|------------------|------|
| `wxSingleInstanceChecker` | `QLockFile`<br>`QSharedMemory` | 文件锁<br>命名管道<br>网络端口检查 | 单实例检查 |

## 19. 事件系统

### 自定义事件

| wxWidgets | Qt 替代方案 | STL/其他替代方案 | 说明 |
|-----------|-------------|------------------|------|
| `wxDEFINE_EVENT()` | `Q_DECLARE_METATYPE`<br>自定义信号 | 观察者模式<br>`std::function`回调 | 事件定义 |
| `wxDECLARE_EVENT()` | 信号声明 | 事件接口声明 | 事件声明 |

## 20. 媒体和MIME

### MIME类型

| wxWidgets | Qt 替代方案 | STL/其他替代方案 | 说明 |
|-----------|-------------|------------------|------|
| `wxMimeTypesManager` | `QMimeDatabase` | `libmagic`<br>平台特定MIME API | MIME类型管理 |

## 21. 输入验证

### 验证器

| wxWidgets | Qt 替代方案 | STL/其他替代方案 | 说明 |
|-----------|-------------|------------------|------|
| `wxTextValidator` | `QValidator`<br>`QRegExpValidator` | `std::regex`<br>自定义验证函数 | 输入验证 |

## 22. 国际化

### 本地化

| wxWidgets | Qt 替代方案 | STL/其他替代方案 | 说明 |
|-----------|-------------|------------------|------|
| `wxTranslation` | `QTranslator` | `gettext`<br>`ICU`库 | 翻译管理 |
| `wxLocale` | `QLocale` | `std::locale`<br>`ICU`库 | 本地化设置 |

## 23. 正则表达式

### 模式匹配

| wxWidgets | Qt 替代方案 | STL/其他替代方案 | 说明 |
|-----------|-------------|------------------|------|
| `wxRegEx` | `QRegularExpression` | `std::regex` | 正则表达式 |

## 24. 常用宏和常量

### 系统常量

| wxWidgets | Qt 替代方案 | STL/其他替代方案 | 说明 |
|-----------|-------------|------------------|------|
| `wxEmptyString` | `QString()` | `std::string()` | 空字符串 |
| `wxDefaultPosition` | `QPoint(-1, -1)` | `{-1, -1}` | 默认位置 |
| `wxDefaultSize` | `QSize(-1, -1)` | `{-1, -1}` | 默认尺寸 |
| `wxID_ANY` | `-1` | `-1` | 任意ID |

## 迁移建议

### 1. 优先级顺序
1. **Qt方案** - 功能最接近，迁移最容易
2. **STL/标准库** - 零依赖，性能好
3. **专业库** - 功能强大，但增加依赖

### 2. 迁移策略
- **渐进式迁移**: 按模块逐步替换
- **接口封装**: 创建抽象层屏蔽具体实现
- **测试驱动**: 确保功能等价性

### 3. 性能考虑
- Qt通常提供与wx相当的性能
- STL方案可能更轻量
- 专业库可能有性能优势

### 4. 平台兼容性
- Qt: 优秀的跨平台支持
- STL: 标准保证的可移植性  
- 专业库: 需要验证平台支持

最后更新: 完整的wx功能替代方案映射