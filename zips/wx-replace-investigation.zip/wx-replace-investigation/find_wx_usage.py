#!/usr/bin/env python3
"""
KiCad wxWidgets Usage Finder
扫描KiCad源码中所有wx功能的使用情况
"""

import os
import re
import json
from pathlib import Path
from collections import defaultdict
from typing import Dict, List, Set, Tuple

class WxUsageFinder:
    def __init__(self, source_dir: str):
        self.source_dir = Path(source_dir)
        self.results = defaultdict(lambda: defaultdict(list))
        
        # 定义要搜索的wx关键字模式
        self.wx_patterns = {
            # 基础数据类型
            'basic_types': [
                r'\bwxString\b',
                r'\bwxArrayString\b', 
                r'\bwxFileName\b',
                r'\bwxVariant\b',
                r'\bwxAny\b',
                r'\bwxBase64\w*\b'
            ],
            
            # 几何和数学
            'geometry': [
                r'\bwxPoint\b',
                r'\bwxRealPoint\b',
                r'\bwxPoint2D\b',
                r'\bwxSize\b',
                r'\bwxRect\b',
                r'\bwxRegion\b',
                r'\bwxCoord\b'
            ],
            
            # 时间和定时器
            'time': [
                r'\bwxDateTime\b',
                r'\bwxTimer\b',
                r'\bwxTimerEvent\b',
                r'\bwxStopWatch\b',
                r'\bwxGetLocalTime\b'
            ],
            
            # 文件和路径
            'file_path': [
                r'\bwxDir\b',
                r'\bwxFile\b',
                r'\bwxTextFile\b',
                r'\bwxStandardPaths\b'
            ],
            
            # 容器和集合
            'containers': [
                r'\bwxArrayInt\b',
                r'\bwxList\b',
                r'\bwxObjectList\b',
                r'\bwxHashMap\b',
                r'\bwxHashSet\b',
                r'\bwxSortedArray\b'
            ],
            
            # 流和序列化
            'streams': [
                r'\bwxInputStream\b',
                r'\bwxOutputStream\b',
                r'\bwxFileInputStream\b',
                r'\bwxFileOutputStream\b',
                r'\bwxMemoryInputStream\b',
                r'\bwxMemoryOutputStream\b',
                r'\bwxTextInputStream\b',
                r'\bwxTextOutputStream\b',
                r'\bwxDataInputStream\b',
                r'\bwxDataOutputStream\b',
                r'\bwxStreamBuffer\b'
            ],
            
            # 压缩和归档
            'archive': [
                r'\bwxZipInputStream\b',
                r'\bwxZipOutputStream\b',
                r'\bwxZipEntry\b',
                r'\bwxArchiveEntry\b'
            ],
            
            # 网络和通信
            'network': [
                r'\bwxSocket\b',
                r'\bwxSocketBase\b',
                r'\bwxURL\b',
                r'\bwxURI\b'
            ],
            
            # 多线程
            'threading': [
                r'\bwxThread\b',
                r'\bwxThreadEvent\b',
                r'\bwxCriticalSection\b',
                r'\bwxMutex\b',
                r'\bwxSemaphore\b',
                r'\bwxCondition\b'
            ],
            
            # XML处理
            'xml': [
                r'\bwxXmlDocument\b',
                r'\bwxXmlNode\b'
            ],
            
            # 配置管理
            'config': [
                r'\bwxConfig\b',
                r'\bwxConfigBase\b',
                r'\bwxFileConfig\b',
                r'\bwxRegConfig\b'
            ],
            
            # 系统集成
            'system': [
                r'\bwxSystemSettings\b',
                r'\bwxSystemAppearance\b',
                r'\bwxPlatformInfo\b',
                r'\bwxOperatingSystemId\b'
            ],
            
            # 日志系统
            'logging': [
                r'\bwxLogTrace\b',
                r'\bwxLogMessage\b',
                r'\bwxLogError\b',
                r'\bwxLogWarning\b',
                r'\bwxLogDebug\b',
                r'\bwxLogVerbose\b',
                r'\bwxLogNull\b'
            ],
            
            # 进程管理
            'process': [
                r'\bwxExecute\b',
                r'\bwxProcess\b'
            ],
            
            # 剪贴板和拖拽
            'clipboard': [
                r'\bwxClipboard\b',
                r'\bwxDropTarget\b',
                r'\bwxDropSource\b',
                r'\bwxDataObject\b'
            ],
            
            # 应用程序框架
            'app_framework': [
                r'\bwxApp\b',
                r'\bwxAppConsole\b',
                r'\bwxCmdLineParser\b',
                r'\bwxCmdLineEntryDesc\b'
            ],
            
            # 调试支持
            'debug': [
                r'\bwxASSERT\b',
                r'\bwxCHECK_MSG\b'
            ],
            
            # 单实例管理
            'singleton': [
                r'\bwxSingleInstanceChecker\b'
            ],
            
            # 事件系统
            'events': [
                r'\bwxDEFINE_EVENT\b',
                r'\bwxDECLARE_EVENT\b',
                r'\bwxEVT_\w+\b'
            ],
            
            # MIME和媒体
            'mime': [
                r'\bwxMimeTypesManager\b'
            ],
            
            # 验证器
            'validators': [
                r'\bwxTextValidator\b'
            ],
            
            # 国际化
            'i18n': [
                r'\bwxTranslation\b',
                r'\bwxLocale\b'
            ],
            
            # 正则表达式
            'regex': [
                r'\bwxRegEx\b'
            ],
            
            # 常用宏和常量
            'macros': [
                r'\bwxEmptyString\b',
                r'\bwxDefaultPosition\b',
                r'\bwxDefaultSize\b',
                r'\bwxID_ANY\b',
                r'\bwxFileSelectorDefaultWildcardStr\b',
                r'\bBEGIN_EVENT_TABLE\b',
                r'\bEND_EVENT_TABLE\b'
            ]
        }
        
        # 文件扩展名过滤
        self.file_extensions = {'.cpp', '.h', '.hpp', '.cc', '.cxx'}
        
        # 排除的目录
        self.exclude_dirs = {'.git', 'build', 'cmake', 'Documentation'}
    
    def should_process_file(self, file_path: Path) -> bool:
        """判断是否应该处理该文件"""
        # 检查文件扩展名
        if file_path.suffix.lower() not in self.file_extensions:
            return False
            
        # 检查是否在排除目录中
        for part in file_path.parts:
            if part in self.exclude_dirs:
                return False
                
        return True
    
    def search_in_file(self, file_path: Path) -> Dict[str, List[Tuple[int, str]]]:
        """在单个文件中搜索wx模式"""
        matches = defaultdict(list)
        
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                lines = f.readlines()
                
            for line_num, line in enumerate(lines, 1):
                for category, patterns in self.wx_patterns.items():
                    for pattern in patterns:
                        if re.search(pattern, line):
                            matches[category].append((line_num, line.strip()))
                            
        except Exception as e:
            print(f"Error reading {file_path}: {e}")
            
        return matches
    
    def scan_directory(self) -> None:
        """扫描整个目录"""
        print(f"Scanning directory: {self.source_dir}")
        
        file_count = 0
        for file_path in self.source_dir.rglob('*'):
            if file_path.is_file() and self.should_process_file(file_path):
                file_count += 1
                if file_count % 100 == 0:
                    print(f"Processed {file_count} files...")
                
                matches = self.search_in_file(file_path)
                if matches:
                    rel_path = file_path.relative_to(self.source_dir)
                    for category, category_matches in matches.items():
                        self.results[category][str(rel_path)].extend(category_matches)
        
        print(f"Completed scanning {file_count} files")
    
    def generate_report(self, output_file: str) -> None:
        """生成分析报告"""
        report = {
            'summary': {},
            'details': {}
        }
        
        # 生成摘要
        for category, files in self.results.items():
            total_matches = sum(len(matches) for matches in files.values())
            report['summary'][category] = {
                'file_count': len(files),
                'total_matches': total_matches
            }
        
        # 详细信息
        report['details'] = dict(self.results)
        
        # 写入JSON文件
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(report, f, indent=2, ensure_ascii=False)
        
        print(f"Report saved to: {output_file}")
    
    def generate_markdown_report(self, output_file: str) -> None:
        """生成Markdown格式的报告"""
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write("# KiCad wxWidgets Usage Analysis Report\n\n")
            
            # 摘要表格
            f.write("## Summary\n\n")
            f.write("| Category | Files | Total Matches |\n")
            f.write("|----------|-------|---------------|\n")
            
            for category, files in sorted(self.results.items()):
                total_matches = sum(len(matches) for matches in files.values())
                f.write(f"| {category} | {len(files)} | {total_matches} |\n")
            
            f.write("\n")
            
            # 详细信息
            f.write("## Detailed Results\n\n")
            
            for category, files in sorted(self.results.items()):
                f.write(f"### {category.title().replace('_', ' ')}\n\n")
                
                for file_path, matches in sorted(files.items()):
                    f.write(f"#### {file_path}\n\n")
                    for line_num, line in matches[:10]:  # 限制显示前10个匹配
                        f.write(f"- Line {line_num}: `{line}`\n")
                    
                    if len(matches) > 10:
                        f.write(f"- ... and {len(matches) - 10} more matches\n")
                    
                    f.write("\n")
        
        print(f"Markdown report saved to: {output_file}")

def main():
    # 配置路径
    source_dir = "."  # 当前目录，假设脚本在KiCad根目录运行
    
    # 创建查找器实例
    finder = WxUsageFinder(source_dir)
    
    # 扫描目录
    finder.scan_directory()
    
    # 生成报告
    finder.generate_report("wx_usage_report.json")
    finder.generate_markdown_report("wx_usage_report.md")
    
    # 打印摘要
    print("\n=== SUMMARY ===")
    total_files = 0
    total_matches = 0
    
    for category, files in sorted(finder.results.items()):
        file_count = len(files)
        match_count = sum(len(matches) for matches in files.values())
        total_files += file_count
        total_matches += match_count
        print(f"{category:20}: {file_count:3} files, {match_count:4} matches")
    
    print(f"\nTotal: {total_files} files with wx usage, {total_matches} total matches")

if __name__ == "__main__":
    main()