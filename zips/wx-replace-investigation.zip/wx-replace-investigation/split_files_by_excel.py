#!/usr/bin/env python3
"""
将C++代码文件根据Excel输入分类为两部分
输入：包含文件路径列表的Excel文件
输出：包含三个sheet页的Excel文件
  - Sheet1: 所有C++文件 (.cpp, .h, .hpp等)
  - Sheet2: 输入Excel中的C++文件
  - Sheet3: 不在输入Excel中的C++文件（补集）
"""

import os
import sys
import argparse
from pathlib import Path
import openpyxl
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from typing import Set, List


def get_all_cpp_files(root_dir: Path, exclude_dirs: Set[str] = None) -> Set[str]:
    """
    获取目录下的所有C++代码文件（相对路径）
    
    Args:
        root_dir: 根目录
        exclude_dirs: 要排除的目录名称集合
        
    Returns:
        所有C++文件的相对路径集合
    """
    if exclude_dirs is None:
        exclude_dirs = {'.git', '__pycache__', 'node_modules', '.vs', 'build', 'dist'}
    
    # C++相关的文件扩展名
    cpp_extensions = {'.cpp', '.h', '.hpp', '.cc', '.cxx', '.hxx', '.c++', '.h++', '.C', '.H'}
    
    all_files = set()
    
    for root, dirs, files in os.walk(root_dir):
        # 排除特定目录
        dirs[:] = [d for d in dirs if d not in exclude_dirs]
        
        for file in files:
            # 检查文件扩展名
            file_path = Path(root) / file
            if file_path.suffix in cpp_extensions:
                relative_path = file_path.relative_to(root_dir)
                # 统一使用反斜杠（Windows风格）
                relative_path_str = str(relative_path).replace('/', '\\')
                all_files.add(relative_path_str)
    
    return all_files


def read_input_excel(excel_path: Path) -> Set[str]:
    """
    读取输入Excel文件中的路径列表
    
    Args:
        excel_path: Excel文件路径
        
    Returns:
        文件路径集合
    """
    input_files = set()
    
    try:
        wb = openpyxl.load_workbook(excel_path)
        # 读取第一个sheet
        sheet = wb.active
        
        # 遍历第一列的所有行
        for row in sheet.iter_rows(min_col=1, max_col=1, values_only=True):
            if row[0]:  # 如果单元格不为空
                path_str = str(row[0]).strip()
                # 统一路径分隔符
                path_str = path_str.replace('/', '\\')
                input_files.add(path_str)
                
    except Exception as e:
        print(f"读取输入Excel文件出错: {e}")
        sys.exit(1)
    
    return input_files


def write_output_excel(output_path: Path, all_files: Set[str], 
                      input_files: Set[str], complement_files: Set[str]):
    """
    写入输出Excel文件
    
    Args:
        output_path: 输出文件路径
        all_files: 所有文件集合
        input_files: 输入Excel中的文件集合
        complement_files: 补集文件集合
    """
    wb = Workbook()
    
    # 创建样式
    header_font = Font(bold=True, size=12)
    header_fill = PatternFill(start_color="D3D3D3", end_color="D3D3D3", fill_type="solid")
    header_alignment = Alignment(horizontal="center", vertical="center")
    
    # Sheet1: 所有C++文件
    sheet1 = wb.active
    sheet1.title = "所有C++文件"
    sheet1['A1'] = "文件路径"
    sheet1['A1'].font = header_font
    sheet1['A1'].fill = header_fill
    sheet1['A1'].alignment = header_alignment
    sheet1['B1'] = f"总计: {len(all_files)} 个C++文件"
    sheet1['B1'].font = header_font
    
    sorted_all = sorted(all_files)
    for idx, file_path in enumerate(sorted_all, 2):
        sheet1[f'A{idx}'] = file_path
    
    # 设置列宽
    sheet1.column_dimensions['A'].width = 80
    sheet1.column_dimensions['B'].width = 20
    
    # Sheet2: 输入Excel中的C++文件
    sheet2 = wb.create_sheet("输入C++文件")
    sheet2['A1'] = "文件路径"
    sheet2['A1'].font = header_font
    sheet2['A1'].fill = header_fill
    sheet2['A1'].alignment = header_alignment
    sheet2['B1'] = f"总计: {len(input_files)} 个C++文件"
    sheet2['B1'].font = header_font
    
    sorted_input = sorted(input_files)
    for idx, file_path in enumerate(sorted_input, 2):
        sheet2[f'A{idx}'] = file_path
    
    sheet2.column_dimensions['A'].width = 80
    sheet2.column_dimensions['B'].width = 20
    
    # Sheet3: 补集（不在输入Excel中的C++文件）
    sheet3 = wb.create_sheet("补集C++文件")
    sheet3['A1'] = "文件路径"
    sheet3['A1'].font = header_font
    sheet3['A1'].fill = header_fill
    sheet3['A1'].alignment = header_alignment
    sheet3['B1'] = f"总计: {len(complement_files)} 个C++文件"
    sheet3['B1'].font = header_font
    
    sorted_complement = sorted(complement_files)
    for idx, file_path in enumerate(sorted_complement, 2):
        sheet3[f'A{idx}'] = file_path
    
    sheet3.column_dimensions['A'].width = 80
    sheet3.column_dimensions['B'].width = 20
    
    # 保存文件
    try:
        wb.save(output_path)
        print(f"✓ 输出文件已保存: {output_path}")
    except Exception as e:
        print(f"保存输出文件出错: {e}")
        sys.exit(1)


def main():
    parser = argparse.ArgumentParser(
        description='根据Excel输入将C++代码文件分类为两部分')
    parser.add_argument('input_excel', 
                       help='输入Excel文件路径')
    parser.add_argument('-o', '--output', 
                       default='cpp_file_classification.xlsx',
                       help='输出Excel文件路径 (默认: cpp_file_classification.xlsx)')
    parser.add_argument('-d', '--directory',
                       default='.',
                       help='要扫描的目录 (默认: 当前目录)')
    parser.add_argument('--exclude-dirs',
                       nargs='*',
                       help='要排除的目录名称')
    
    args = parser.parse_args()
    
    # 路径处理
    input_excel_path = Path(args.input_excel)
    output_excel_path = Path(args.output)
    scan_directory = Path(args.directory).resolve()
    
    # 检查输入文件是否存在
    if not input_excel_path.exists():
        print(f"错误: 输入文件不存在: {input_excel_path}")
        sys.exit(1)
    
    # 检查扫描目录是否存在
    if not scan_directory.exists():
        print(f"错误: 扫描目录不存在: {scan_directory}")
        sys.exit(1)
    
    print(f"扫描目录: {scan_directory}")
    print(f"输入Excel: {input_excel_path}")
    print(f"输出Excel: {output_excel_path}")
    print()
    
    # 设置要排除的目录
    exclude_dirs = {'.git', '__pycache__', 'node_modules', '.vs', 'build', 'dist'}
    if args.exclude_dirs:
        exclude_dirs.update(args.exclude_dirs)
    
    # 步骤1: 获取所有C++文件
    print("正在扫描所有C++文件...")
    all_files = get_all_cpp_files(scan_directory, exclude_dirs)
    print(f"  找到 {len(all_files)} 个C++文件")
    
    # 步骤2: 读取输入Excel
    print("正在读取输入Excel...")
    input_files_raw = read_input_excel(input_excel_path)
    print(f"  读取到 {len(input_files_raw)} 个路径")
    
    # 步骤3: 找出实际存在的输入C++文件
    input_files = input_files_raw & all_files  # 交集
    not_found = input_files_raw - all_files  # 在输入中但不存在的C++文件
    
    if not_found:
        print(f"\n警告: 以下 {len(not_found)} 个文件在输入Excel中但不是C++文件或不存在:")
        for f in sorted(not_found)[:10]:  # 只显示前10个
            print(f"  - {f}")
        if len(not_found) > 10:
            print(f"  ... 还有 {len(not_found) - 10} 个文件")
    
    # 步骤4: 计算补集
    complement_files = all_files - input_files
    
    # 验证
    assert len(input_files) + len(complement_files) == len(all_files), \
        "错误: 文件集合计算有误"
    
    print(f"\n统计:")
    print(f"  所有C++文件: {len(all_files)}")
    print(f"  输入C++文件(存在的): {len(input_files)}")
    print(f"  补集C++文件: {len(complement_files)}")
    
    # 步骤5: 写入输出Excel
    print("\n正在生成输出Excel...")
    write_output_excel(output_excel_path, all_files, input_files, complement_files)
    
    print("\n完成!")
    print(f"Sheet1 (所有C++文件): {len(all_files)} 个")
    print(f"Sheet2 (输入C++文件): {len(input_files)} 个")
    print(f"Sheet3 (补集C++文件): {len(complement_files)} 个")
    print(f"验证: Sheet2 + Sheet3 = {len(input_files)} + {len(complement_files)} = {len(input_files) + len(complement_files)}")


if __name__ == "__main__":
    main()