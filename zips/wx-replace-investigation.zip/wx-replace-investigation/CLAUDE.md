# KiCad wxWidgets UI文件分析与迁移项目

## 项目概述
本项目旨在分析KiCad源代码中所有与wxWidgets UI相关的文件，为未来可能的UI框架迁移或创建无GUI版本提供详细的技术参考。

## 项目背景
KiCad是一个大型的开源EDA（电子设计自动化）软件，使用wxWidgets作为GUI框架。项目包含约8000+个UI相关文件，包括自动生成的UI代码、手写的UI逻辑和大量的图标资源。

## 已完成的工作

### 1. wxWidgets非UI功能映射表
创建了完整的非UI功能替换映射表（`wx-replace-map.md`），涵盖25个主要类别：
- 字符串和数据类型（wxString, wxArrayString等）
- 文件和路径操作（wxFileName, wxDir等）
- 时间和日期功能（wxDateTime, wxTimer等）
- 几何和数学（wxPoint, wxRect等）
- 网络和通信（wxSocket, TCP/IP端口等）
- 多线程和并发（wxThread, wxMutex等）
- 压缩和归档（wxZipInputStream/OutputStream）
- 应用程序框架（wxAppConsole, wxCmdLineParser）

### 2. UI文件识别与分类系统

#### 2.1 文件类型统计
- **自动生成文件**: ~1,225个
  - .fbp文件（wxFormBuilder项目文件）: 245个
  - *_base.cpp文件: ~490个
  - *_base.h文件: ~490个

- **手写UI文件**: ~500个
  - 对话框/面板文件
  - 菜单栏文件（menubar.cpp等）
  - 工具栏文件（toolbar*.cpp等）
  - 画布/视图文件（*canvas*, *view*等）
  - 打印/绘图文件（*print*, *plot*等）
  - 设置/选项文件（*settings*, *options*等）

- **UI资源文件**: ~6,300个
  - PNG图标文件: 5,035个
  - SVG矢量图文件: 1,255个
  - ICO应用图标: 17个

**总计**: 约8,000+个UI相关文件

#### 2.2 三级安全分类策略

**Level 1 - 自动生成（100%安全删除）**
- wxFormBuilder生成的文件
- 文件头包含"PLEASE DO *NOT* EDIT THIS FILE!"
- 纯UI布局代码，无业务逻辑

**Level 2 - 纯UI文件（较安全删除）**
- 明确的UI文件名模式（menubar, toolbar, dialog_, panel_等）
- 纯UI控件包装类
- 不包含核心业务逻辑

**Level 3 - 需要内容分析（谨慎处理）**
- Level 3A - 继承关系：继承自wxDialog/wxPanel/wxFrame等
- Level 3B - UI密度：UI控件关键词密度>5%
- Level 3C - 事件处理：事件处理函数占比>30%

### 3. 开发的分析工具

#### 3.1 `identify_ui_files.py`
基础UI文件识别脚本，功能包括：
- 自动识别所有UI相关文件
- 分类统计各类UI文件
- 生成JSON格式的详细报告
- 自动生成删除脚本（.sh/.bat）

#### 3.2 `analyze_ui_files_to_excel.py`
高级分析脚本，输出Excel报告：
- 完整目录扫描
- 智能文件分组（.fbp与对应的base文件）
- 多维度分析（继承关系、UI密度、事件处理）
- 生成6个Sheet页的详细报告

### 4. UI文件识别标准

#### 4.1 自动生成文件识别
```cpp
// C++ code generated with wxFormBuilder (version 4.2.1-0-g80c4cb6)
// PLEASE DO *NOT* EDIT THIS FILE!
```

#### 4.2 UI密度计算
检测的UI关键词包括：
- **wxWidgets控件**: wxButton, wxTextCtrl, wxListBox, wxComboBox, wxCheckBox, wxRadioButton, wxStaticText, wxGrid, wxTreeCtrl等
- **布局组件**: wxSizer, wxBoxSizer, wxFlexGridSizer, wxGridSizer
- **事件宏**: EVT_BUTTON, EVT_MENU, EVT_TOOL, EVT_TEXT, EVT_CHOICE等
- **UI函数**: SetSizer, Layout, Centre, SetTitle, SetIcon, CreateStatusBar, CreateToolBar等

#### 4.3 事件处理模式识别
- 事件表定义：BEGIN_EVENT_TABLE / END_EVENT_TABLE
- 事件绑定宏：EVT_* 系列
- 动态事件连接：Connect(wxEVT_*), Bind(wxEVT_*)
- 事件占比计算：事件处理函数数 / 总函数数 * 100%

### 5. 重要发现

#### 5.1 文件组织模式
KiCad的UI文件遵循清晰的组织模式：
- 每个对话框/面板通常有3个文件：.fbp（设计）、*_base.cpp/h（生成）、*.cpp/h（实现）
- 菜单和工具栏文件按模块组织（如pcbnew/menubar_pcb_editor.cpp）
- 资源文件集中在resources/目录下

#### 5.2 UI与业务逻辑的耦合
- 大部分UI文件与业务逻辑有一定耦合
- 纯UI文件主要是自动生成的base文件
- 事件处理文件通常混合UI响应和业务逻辑

#### 5.3 可迁移性评估
- Level 1文件（~1,225个）可直接删除或替换
- Level 2文件（~500个）需要简单重构即可迁移
- Level 3文件需要仔细分离UI和业务逻辑
- 资源文件可在任何UI框架中重用

## 使用指南

### 运行分析脚本
```bash
# 基础分析
python identify_ui_files.py

# 生成Excel报告
pip install openpyxl
python analyze_ui_files_to_excel.py

# 分析特定目录
python analyze_ui_files_to_excel.py /path/to/kicad -o report.xlsx
```

### Excel报告说明
生成的Excel包含以下Sheet页：
1. **统计汇总** - 总体统计和说明
2. **Level1_自动生成** - wxFormBuilder生成的文件
3. **Level2_纯UI文件** - 明确的UI文件
4. **Level3A_继承关系** - 继承自wx UI类的文件
5. **Level3B_UI密度** - UI控件密度高的文件
6. **Level3C_事件处理** - 事件处理为主的文件
7. **资源文件** - PNG/SVG/ICO等资源

## 下一步计划

### 短期目标
1. 完善UI文件的自动分类算法
2. 开发UI代码自动重构工具
3. 创建UI框架迁移的概念验证

### 长期目标
1. 实现KiCad核心功能与UI的完全解耦
2. 支持多种UI框架（Qt、Dear ImGui等）
3. 创建headless版本用于自动化和CI/CD

## 技术建议

### 对于想要创建无GUI版本的开发者
1. 首先删除所有Level 1文件（自动生成）
2. 评估Level 2文件的业务逻辑依赖
3. 重构Level 3文件，分离UI和业务逻辑
4. 保留必要的数据结构和算法

### 对于UI框架迁移
1. 保持现有的MVC架构模式
2. 创建抽象的UI接口层
3. 逐模块迁移，从简单的对话框开始
4. 充分利用自动化工具减少手工工作

## wxWidgets非UI元素完整清单

### 基础数据类型
- **wxString** - 字符串类，替代std::string
- **wxArrayString** - 字符串数组，替代std::vector<std::string>
- **wxFileName** - 文件名和路径处理类
- **wxVariant** - 通用数据类型容器
- **wxAny** - 任意类型数据容器
- **wxBase64** - Base64编码解码功能

### 几何和数学
- **wxPoint** - 2D点坐标
- **wxRealPoint** - 实数坐标点
- **wxPoint2D** - 2D双精度点
- **wxSize** - 尺寸（宽度和高度）
- **wxRect** - 矩形区域
- **wxRegion** - 几何区域
- **wxCoord** - 坐标类型定义

### 时间和定时器
- **wxDateTime** - 日期时间处理类
- **wxTimer** - 定时器类
- **wxTimerEvent** - 定时器事件
- **wxStopWatch** - 秒表计时器
- **wxGetLocalTime** - 获取本地时间函数

### 文件和路径操作
- **wxDir** - 目录操作类
- **wxFile** - 文件操作类
- **wxTextFile** - 文本文件操作
- **wxStandardPaths** - 标准路径获取

### 容器和集合
- **wxArrayInt** - 整数数组
- **wxList** - 链表容器
- **wxObjectList** - 对象链表
- **wxHashMap** - 哈希映射
- **wxHashSet** - 哈希集合
- **wxSortedArray** - 排序数组

### 流和序列化
- **wxInputStream** - 输入流基类
- **wxOutputStream** - 输出流基类
- **wxFileInputStream** - 文件输入流
- **wxFileOutputStream** - 文件输出流
- **wxMemoryInputStream** - 内存输入流
- **wxMemoryOutputStream** - 内存输出流
- **wxTextInputStream** - 文本输入流
- **wxTextOutputStream** - 文本输出流
- **wxDataInputStream** - 数据输入流
- **wxDataOutputStream** - 数据输出流
- **wxStreamBuffer** - 流缓冲区

### 压缩和归档
- **wxZipInputStream** - ZIP解压输入流
- **wxZipOutputStream** - ZIP压缩输出流
- **wxZipEntry** - ZIP条目
- **wxArchiveEntry** - 归档条目基类

### 网络和通信
- **wxSocket** - 套接字基类
- **wxSocketBase** - 套接字基础类
- **wxURL** - URL处理类
- **wxURI** - URI处理类

### 多线程和并发
- **wxThread** - 线程类
- **wxThreadEvent** - 线程事件
- **wxCriticalSection** - 临界区
- **wxMutex** - 互斥锁
- **wxSemaphore** - 信号量
- **wxCondition** - 条件变量

### XML处理
- **wxXmlDocument** - XML文档类
- **wxXmlNode** - XML节点类

### 配置管理
- **wxConfig** - 配置管理基类
- **wxConfigBase** - 配置基础类
- **wxFileConfig** - 文件配置类
- **wxRegConfig** - 注册表配置类

### 系统集成
- **wxSystemSettings** - 系统设置获取
- **wxSystemAppearance** - 系统外观信息
- **wxPlatformInfo** - 平台信息
- **wxOperatingSystemId** - 操作系统标识

### 日志系统
- **wxLogTrace** - 跟踪日志
- **wxLogMessage** - 消息日志
- **wxLogError** - 错误日志
- **wxLogWarning** - 警告日志
- **wxLogDebug** - 调试日志
- **wxLogVerbose** - 详细日志
- **wxLogNull** - 禁用日志

### 进程管理
- **wxExecute** - 执行外部程序
- **wxProcess** - 进程控制类

### 剪贴板和拖拽
- **wxClipboard** - 剪贴板操作
- **wxDropTarget** - 拖放目标
- **wxDropSource** - 拖放源
- **wxDataObject** - 数据对象

### 应用程序框架
- **wxApp** - 应用程序基类
- **wxAppConsole** - 控制台应用程序
- **wxCmdLineParser** - 命令行解析器
- **wxCmdLineEntryDesc** - 命令行条目描述

### 调试支持
- **wxASSERT** - 断言宏
- **wxCHECK_MSG** - 检查消息宏

### 单实例管理
- **wxSingleInstanceChecker** - 单实例检查器

### 事件系统
- **wxDEFINE_EVENT** - 事件定义宏
- **wxDECLARE_EVENT** - 事件声明宏
- **wxEVT_*** - 各种事件类型常量

### MIME和媒体
- **wxMimeTypesManager** - MIME类型管理器

### 验证器
- **wxTextValidator** - 文本验证器

### 国际化
- **wxTranslation** - 翻译支持
- **wxLocale** - 本地化设置

### 正则表达式
- **wxRegEx** - 正则表达式类

### 常用宏和常量
- **wxEmptyString** - 空字符串常量
- **wxDefaultPosition** - 默认位置
- **wxDefaultSize** - 默认大小
- **wxID_ANY** - 任意ID常量
- **wxFileSelectorDefaultWildcardStr** - 文件选择器默认通配符
- **BEGIN_EVENT_TABLE** - 事件表开始宏
- **END_EVENT_TABLE** - 事件表结束宏

## 项目文件清单

### 生成的分析工具和脚本

#### UI文件分析工具
- `wx-replace-map.md` - wxWidgets非UI功能映射表
- `wx-ui-files-analysis.md` - UI文件分析报告
- `identify_ui_files.py` - 基础UI文件识别脚本
- `analyze_ui_files_to_excel.py` - 高级分析脚本（Excel输出）
- `ui_files_analysis.json` - 详细的文件分类数据
- `ui_files_analysis.xlsx` - Excel格式的分析报告
- `delete_ui_files.sh` - Linux/macOS删除脚本
- `delete_ui_files.bat` - Windows删除脚本

#### wx非UI元素统计工具
- `find_wx_usage.py` - wx元素使用情况查找器（基础版本）
- `find_wx_usage_jsonl.py` - wx元素使用情况查找器（JSONL输出）
- `find_wx_usage_with_lines.py` - wx元素使用情况查找器（包含行号）
- `wx_elements_to_excel.py` - 基于JSONL生成Excel统计报告
- `wx_elements_to_excel_with_lines.py` - 基于包含行号的JSONL生成Excel统计报告
- `wx_elements_direct_to_excel.py` - 直接扫描源码并生成Excel统计报告（推荐使用）
- `wx_usage_results.jsonl` - wx元素使用情况数据（JSONL格式）
- `wx_elements_statistics_final.xlsx` - wx非UI元素完整统计Excel报告

### 原始数据统计
- 总代码文件数：~15,000+
- UI相关文件数：~8,000+
- 核心算法文件：~7,000+
- 项目总大小：~500MB（不含构建产物）

## 联系与贡献
本分析项目是KiCad源码研究的一部分，旨在为社区提供技术参考。如有问题或建议，欢迎通过GitHub Issues交流。

---
*最后更新: 2025年*
*基于KiCad源码的完整分析*