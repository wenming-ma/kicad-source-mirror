#!/usr/bin/env python3
"""
基于find_wx_usage_jsonl.py的结果，生成wx非UI元素统计Excel表格
首页统计每个wx非UI元素出现的次数，每行一个元素，并添加链接跳转到详细页面
"""

import json
import os
import re
from pathlib import Path
from collections import defaultdict, Counter
from typing import Dict, List, Tuple
import openpyxl
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.hyperlink import Hyperlink


class WxElementsToExcel:
    def __init__(self, jsonl_file: str):
        self.jsonl_file = jsonl_file
        self.element_details = defaultdict(list)  # 元素名 -> [(文件路径, 行号列表), ...]
        self.element_counts = Counter()  # 元素名 -> 总出现次数
        self.category_mapping = self._build_category_mapping()
        
    def _build_category_mapping(self):
        """构建wx元素到类别的映射，基于find_wx_usage_jsonl.py中的模式"""
        patterns = {
            # 基础数据类型
            'basic_types': [
                'wxString', 'wxArrayString', 'wxFileName', 'wxVariant', 'wxAny', 'wxBase64'
            ],
            
            # 几何和数学
            'geometry': [
                'wxPoint', 'wxRealPoint', 'wxPoint2D', 'wxSize', 'wxRect', 'wxRegion', 'wxCoord'
            ],
            
            # 时间和定时器
            'time': [
                'wxDateTime', 'wxTimer', 'wxTimerEvent', 'wxStopWatch', 'wxGetLocalTime'
            ],
            
            # 文件和路径
            'file_path': [
                'wxDir', 'wxFile', 'wxTextFile', 'wxStandardPaths'
            ],
            
            # 容器和集合
            'containers': [
                'wxArrayInt', 'wxList', 'wxObjectList', 'wxHashMap', 'wxHashSet', 'wxSortedArray'
            ],
            
            # 流和序列化
            'streams': [
                'wxInputStream', 'wxOutputStream', 'wxFileInputStream', 'wxFileOutputStream',
                'wxMemoryInputStream', 'wxMemoryOutputStream', 'wxTextInputStream', 'wxTextOutputStream',
                'wxDataInputStream', 'wxDataOutputStream', 'wxStreamBuffer'
            ],
            
            # 压缩和归档
            'archive': [
                'wxZipInputStream', 'wxZipOutputStream', 'wxZipEntry', 'wxArchiveEntry'
            ],
            
            # 网络和通信
            'network': [
                'wxSocket', 'wxSocketBase', 'wxURL', 'wxURI'
            ],
            
            # 多线程
            'threading': [
                'wxThread', 'wxThreadEvent', 'wxCriticalSection', 'wxMutex', 'wxSemaphore', 'wxCondition'
            ],
            
            # XML处理
            'xml': [
                'wxXmlDocument', 'wxXmlNode'
            ],
            
            # 配置管理
            'config': [
                'wxConfig', 'wxConfigBase', 'wxFileConfig', 'wxRegConfig'
            ],
            
            # 系统集成
            'system': [
                'wxSystemSettings', 'wxSystemAppearance', 'wxPlatformInfo', 'wxOperatingSystemId'
            ],
            
            # 日志系统
            'logging': [
                'wxLogTrace', 'wxLogMessage', 'wxLogError', 'wxLogWarning', 'wxLogDebug', 'wxLogVerbose', 'wxLogNull'
            ],
            
            # 进程管理
            'process': [
                'wxExecute', 'wxProcess'
            ],
            
            # 剪贴板和拖拽
            'clipboard': [
                'wxClipboard', 'wxDropTarget', 'wxDropSource', 'wxDataObject'
            ],
            
            # 应用程序框架
            'app_framework': [
                'wxApp', 'wxAppConsole', 'wxCmdLineParser', 'wxCmdLineEntryDesc'
            ],
            
            # 调试支持
            'debug': [
                'wxASSERT', 'wxCHECK_MSG'
            ],
            
            # 单实例管理
            'singleton': [
                'wxSingleInstanceChecker'
            ],
            
            # 事件系统
            'events': [
                'wxDEFINE_EVENT', 'wxDECLARE_EVENT'
            ],
            
            # MIME和媒体
            'mime': [
                'wxMimeTypesManager'
            ],
            
            # 验证器
            'validators': [
                'wxTextValidator'
            ],
            
            # 国际化
            'i18n': [
                'wxTranslation', 'wxLocale'
            ],
            
            # 正则表达式
            'regex': [
                'wxRegEx'
            ],
            
            # 常用宏和常量
            'macros': [
                'wxEmptyString', 'wxDefaultPosition', 'wxDefaultSize', 'wxID_ANY',
                'wxFileSelectorDefaultWildcardStr', 'BEGIN_EVENT_TABLE', 'END_EVENT_TABLE'
            ]
        }
        
        # 构建反向映射：元素名 -> 类别
        element_to_category = {}
        for category, elements in patterns.items():
            for element in elements:
                # 支持模糊匹配，处理变体
                element_to_category[element] = category
        
        return element_to_category
    
    def parse_jsonl_file(self):
        """解析JSONL文件，提取wx元素使用情况"""
        print(f"Reading JSONL file: {self.jsonl_file}")
        
        if not os.path.exists(self.jsonl_file):
            print(f"Error: JSONL file {self.jsonl_file} not found!")
            return
        
        with open(self.jsonl_file, 'r', encoding='utf-8') as f:
            for line_num, line in enumerate(f, 1):
                try:
                    data = json.loads(line.strip())
                    file_path = data['file']
                    wx_elements = data['wx_elements']
                    
                    # 处理每个类别的wx元素
                    for category, elements in wx_elements.items():
                        for element in elements:
                            # 统计元素出现次数
                            self.element_counts[element] += 1
                            
                            # 记录详细信息（文件路径）
                            self.element_details[element].append(file_path)
                            
                except json.JSONDecodeError as e:
                    print(f"Error parsing line {line_num}: {e}")
                except KeyError as e:
                    print(f"Missing key in line {line_num}: {e}")
        
        print(f"Processed {len(self.element_counts)} unique wx elements")
        print(f"Total occurrences: {sum(self.element_counts.values())}")
    
    def get_element_category(self, element: str) -> str:
        """获取元素的类别"""
        # 直接匹配
        if element in self.category_mapping:
            return self.category_mapping[element]
        
        # 模糊匹配 - 处理wxEVT_开头的事件
        if element.startswith('wxEVT_'):
            return 'events'
        
        # 其他模糊匹配规则
        for category_element, category in self.category_mapping.items():
            if category_element in element:
                return category
        
        return 'others'  # 未分类
    
    def create_excel_report(self, output_file: str):
        """创建Excel报告"""
        print(f"Creating Excel report: {output_file}")
        
        wb = Workbook()
        
        # 创建统计汇总页面
        self._create_summary_sheet(wb)
        
        # 为每个wx元素创建详细页面
        self._create_detail_sheets(wb)
        
        # 删除默认的空白工作表
        if 'Sheet' in wb.sheetnames:
            wb.remove(wb['Sheet'])
        
        # 保存工作簿
        wb.save(output_file)
        print(f"Excel report saved to: {output_file}")
    
    def _create_summary_sheet(self, wb: Workbook):
        """创建统计汇总页面"""
        ws = wb.active
        ws.title = "WX元素统计"
        
        # 设置标题样式
        title_font = Font(name='Microsoft YaHei', size=14, bold=True)
        header_font = Font(name='Microsoft YaHei', size=11, bold=True, color='FFFFFF')
        cell_font = Font(name='Microsoft YaHei', size=10)
        
        header_fill = PatternFill(start_color='366092', end_color='366092', fill_type='solid')
        center_alignment = Alignment(horizontal='center', vertical='center')
        
        # 设置标题
        ws.merge_cells('A1:E1')
        ws['A1'] = 'KiCad项目wx非UI元素使用统计'
        ws['A1'].font = title_font
        ws['A1'].alignment = center_alignment
        
        # 设置表头
        headers = ['序号', 'wx元素', '类别', '出现次数', '详细信息']
        for col, header in enumerate(headers, 1):
            cell = ws.cell(row=3, column=col, value=header)
            cell.font = header_font
            cell.fill = header_fill
            cell.alignment = center_alignment
        
        # 按出现次数排序的wx元素
        sorted_elements = sorted(self.element_counts.items(), key=lambda x: x[1], reverse=True)
        
        # 填充数据
        for row, (element, count) in enumerate(sorted_elements, 4):
            category = self.get_element_category(element)
            
            ws.cell(row=row, column=1, value=row-3).font = cell_font  # 序号
            ws.cell(row=row, column=2, value=element).font = cell_font  # wx元素
            ws.cell(row=row, column=3, value=category).font = cell_font  # 类别
            ws.cell(row=row, column=4, value=count).font = cell_font  # 出现次数
            
            # 创建到详细页面的超链接
            detail_cell = ws.cell(row=row, column=5, value=f"查看详情 ({len(self.element_details[element])} 个文件)")
            detail_cell.font = Font(name='Microsoft YaHei', size=10, color='0000FF', underline='single')
            detail_cell.hyperlink = f"#{self._get_sheet_name(element)}!A1"
        
        # 调整列宽
        ws.column_dimensions['A'].width = 8
        ws.column_dimensions['B'].width = 25
        ws.column_dimensions['C'].width = 15
        ws.column_dimensions['D'].width = 12
        ws.column_dimensions['E'].width = 25
        
        # 添加统计信息
        total_elements = len(self.element_counts)
        total_occurrences = sum(self.element_counts.values())
        total_files = len(set(file for files in self.element_details.values() for file in files))
        
        info_row = len(sorted_elements) + 6
        ws.cell(row=info_row, column=1, value=f"统计信息：").font = Font(name='Microsoft YaHei', size=11, bold=True)
        ws.cell(row=info_row+1, column=1, value=f"• 不重复的wx元素数量: {total_elements}").font = cell_font
        ws.cell(row=info_row+2, column=1, value=f"• wx元素总出现次数: {total_occurrences}").font = cell_font
        ws.cell(row=info_row+3, column=1, value=f"• 涉及的文件数量: {total_files}").font = cell_font
    
    def _create_detail_sheets(self, wb: Workbook):
        """为每个wx元素创建详细页面"""
        header_font = Font(name='Microsoft YaHei', size=11, bold=True, color='FFFFFF')
        cell_font = Font(name='Microsoft YaHei', size=10)
        header_fill = PatternFill(start_color='366092', end_color='366092', fill_type='solid')
        center_alignment = Alignment(horizontal='center', vertical='center')
        
        for element in sorted(self.element_details.keys()):
            # 创建工作表
            sheet_name = self._get_sheet_name(element)
            ws = wb.create_sheet(title=sheet_name)
            
            # 设置标题
            ws.merge_cells('A1:C1')
            ws['A1'] = f'wx元素详情: {element}'
            ws['A1'].font = Font(name='Microsoft YaHei', size=14, bold=True)
            ws['A1'].alignment = center_alignment
            
            # 设置统计信息
            category = self.get_element_category(element)
            count = self.element_counts[element]
            file_count = len(set(self.element_details[element]))
            
            ws['A2'] = f'类别: {category}'
            ws['A3'] = f'总出现次数: {count}'
            ws['A4'] = f'涉及文件数: {file_count}'
            
            # 设置表头
            headers = ['序号', '文件路径', '相对路径']
            for col, header in enumerate(headers, 1):
                cell = ws.cell(row=6, column=col, value=header)
                cell.font = header_font
                cell.fill = header_fill
                cell.alignment = center_alignment
            
            # 统计每个文件的出现次数
            file_counts = Counter(self.element_details[element])
            
            # 按文件路径排序
            sorted_files = sorted(file_counts.items())
            
            # 填充文件数据
            for row, (file_path, file_count) in enumerate(sorted_files, 7):
                ws.cell(row=row, column=1, value=row-6).font = cell_font  # 序号
                ws.cell(row=row, column=2, value=file_path).font = cell_font  # 文件路径
                
                # 提取相对路径的最后部分作为文件名
                file_name = Path(file_path).name
                ws.cell(row=row, column=3, value=file_name).font = cell_font  # 文件名
            
            # 调整列宽
            ws.column_dimensions['A'].width = 8
            ws.column_dimensions['B'].width = 80
            ws.column_dimensions['C'].width = 25
            
            # 添加返回汇总页的链接
            back_row = len(sorted_files) + 9
            back_cell = ws.cell(row=back_row, column=1, value="← 返回汇总页")
            back_cell.font = Font(name='Microsoft YaHei', size=10, color='0000FF', underline='single')
            back_cell.hyperlink = "#WX元素统计!A1"
    
    def _get_sheet_name(self, element: str) -> str:
        """生成合法的工作表名称（Excel工作表名称有长度和字符限制）"""
        # Excel工作表名称限制：最长31个字符，不能包含: \ / ? * [ ]
        safe_name = element.replace('\\', '_').replace('/', '_').replace('?', '_').replace('*', '_').replace('[', '_').replace(']', '_')
        if len(safe_name) > 31:
            safe_name = safe_name[:28] + "..."
        return safe_name


def main():
    """主函数"""
    # 配置文件路径
    jsonl_file = "wx_usage_results.jsonl"
    output_file = "wx_elements_statistics.xlsx"
    
    if not os.path.exists(jsonl_file):
        print(f"Error: Input file {jsonl_file} not found!")
        print("Please run find_wx_usage_jsonl.py first to generate the JSONL data.")
        return
    
    # 创建分析器
    analyzer = WxElementsToExcel(jsonl_file)
    
    # 解析JSONL数据
    analyzer.parse_jsonl_file()
    
    # 生成Excel报告
    analyzer.create_excel_report(output_file)
    
    print(f"\nExcel报告生成完成!")
    print(f"统计汇总: {len(analyzer.element_counts)} 个不重复的wx元素")
    print(f"输出文件: {output_file}")
    print(f"打开Excel文件查看详细的wx元素使用统计和跳转链接")


if __name__ == "__main__":
    main()