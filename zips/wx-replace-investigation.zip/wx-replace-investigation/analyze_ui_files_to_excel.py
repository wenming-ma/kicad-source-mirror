#!/usr/bin/env python3
"""
KiCad UI文件分级分析脚本 - 输出到Excel
将UI文件按安全级别分类，并输出到Excel文件的不同Sheet页
"""

import os
import re
import sys
from pathlib import Path
from typing import Dict, List, Tuple, Set
import openpyxl
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

class UIFileAnalyzer:
    """UI文件分析器"""
    
    def __init__(self, root_dir='.'):
        self.root_dir = Path(root_dir).resolve()
        self.exclude_dirs = {'.git', 'build', 'Debug', 'Release', 'thirdparty', '__pycache__'}
        
        # 文件分组结果
        self.file_groups = {
            'level1_auto_generated': [],      # 级别1：自动生成的文件
            'level2_pure_ui': [],              # 级别2：纯UI文件
            'level3_inheritance': [],          # 级别3A：基于继承关系
            'level3_ui_density': [],           # 级别3B：UI控件密度高
            'level3_event_handlers': [],       # 级别3C：事件处理为主
            'resources': []                    # 资源文件
        }
        
        # 文件关联映射 (用于分组显示)
        self.file_associations = {}  # {base_name: [fbp, cpp, h]}
        
    def scan_directory(self, directory=None):
        """扫描目录中的所有文件"""
        if directory is None:
            directory = self.root_dir
            
        all_files = []
        for root, dirs, files in os.walk(directory):
            # 排除不需要的目录
            dirs[:] = [d for d in dirs if d not in self.exclude_dirs]
            
            for file in files:
                filepath = Path(root) / file
                all_files.append(filepath)
                
        return all_files
    
    def is_auto_generated(self, filepath):
        """检查是否为自动生成的文件"""
        if filepath.suffix == '.fbp':
            return True
            
        if '_base' in filepath.stem and filepath.suffix in ['.cpp', '.h']:
            try:
                with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read(500)
                    if 'PLEASE DO *NOT* EDIT THIS FILE' in content or \
                       'C++ code generated with wxFormBuilder' in content:
                        return True
            except:
                pass
        return False
    
    def check_inheritance(self, filepath):
        """检查继承关系 - 返回匹配的UI基类"""
        if filepath.suffix not in ['.cpp', '.h']:
            return []
            
        ui_base_patterns = [
            (r'class\s+\w+\s*:\s*public\s+wxDialog', 'wxDialog'),
            (r'class\s+\w+\s*:\s*public\s+wxPanel', 'wxPanel'),
            (r'class\s+\w+\s*:\s*public\s+wxFrame', 'wxFrame'),
            (r'class\s+\w+\s*:\s*public\s+\w*DIALOG_\w+_BASE', 'DIALOG_BASE'),
            (r'class\s+\w+\s*:\s*public\s+\w*PANEL_\w+_BASE', 'PANEL_BASE'),
            (r'class\s+\w+\s*:\s*public\s+wxScrolledWindow', 'wxScrolledWindow'),
            (r'class\s+\w+\s*:\s*public\s+wxScrolledCanvas', 'wxScrolledCanvas')
        ]
        
        matched_bases = []
        try:
            with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read(10000)
                for pattern, base_name in ui_base_patterns:
                    if re.search(pattern, content):
                        matched_bases.append(base_name)
        except:
            pass
            
        return matched_bases
    
    def calculate_ui_density(self, filepath):
        """计算UI控件密度 - 返回(UI关键词数, 总行数, 密度百分比)"""
        if filepath.suffix not in ['.cpp', '.h']:
            return 0, 0, 0
            
        ui_keywords = [
            # wxWidgets控件
            'wxButton', 'wxTextCtrl', 'wxListBox', 'wxComboBox', 'wxCheckBox',
            'wxRadioButton', 'wxStaticText', 'wxStaticBitmap', 'wxGrid',
            'wxTreeCtrl', 'wxListCtrl', 'wxNotebook', 'wxPanel', 'wxDialog',
            'wxFrame', 'wxMenuBar', 'wxMenu', 'wxToolBar', 'wxStatusBar',
            'wxSizer', 'wxBoxSizer', 'wxFlexGridSizer', 'wxGridSizer',
            
            # 事件
            'EVT_BUTTON', 'EVT_MENU', 'EVT_TOOL', 'EVT_TEXT', 'EVT_CHOICE',
            'EVT_LISTBOX', 'EVT_CHECKBOX', 'EVT_RADIOBOX', 'EVT_CLOSE',
            'EVT_SIZE', 'EVT_PAINT', 'EVT_MOUSE', 'EVT_KEY',
            
            # UI相关函数
            'SetSizer', 'Layout', 'Centre', 'SetTitle', 'SetIcon',
            'CreateStatusBar', 'CreateToolBar', 'AppendMenu', 'AddTool'
        ]
        
        try:
            with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
                lines = content.split('\n')
                total_lines = len(lines)
                
                # 统计UI关键词出现次数
                ui_count = 0
                for keyword in ui_keywords:
                    ui_count += content.count(keyword)
                
                # 计算密度（每100行的UI关键词数）
                if total_lines > 0:
                    density = (ui_count / total_lines) * 100
                else:
                    density = 0
                    
                return ui_count, total_lines, round(density, 2)
        except:
            return 0, 0, 0
    
    def check_event_handlers(self, filepath):
        """检查事件处理模式 - 返回(事件数, 函数数, 比例)"""
        if filepath.suffix not in ['.cpp', '.h']:
            return 0, 0, 0
            
        try:
            with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
                
                # 统计事件处理
                event_patterns = [
                    r'EVT_\w+\s*\(',  # 事件绑定
                    r'BEGIN_EVENT_TABLE',  # 事件表
                    r'Connect\s*\(\s*\w+,\s*wxEVT_',  # 动态事件连接
                    r'Bind\s*\(\s*wxEVT_'  # 事件绑定
                ]
                
                event_count = 0
                for pattern in event_patterns:
                    matches = re.findall(pattern, content)
                    event_count += len(matches)
                
                # 统计所有函数
                function_pattern = r'^\s*(?:void|bool|int|wxString|auto)\s+\w+::\w+\s*\('
                functions = re.findall(function_pattern, content, re.MULTILINE)
                function_count = len(functions)
                
                # 计算比例
                if function_count > 0:
                    ratio = (event_count / function_count) * 100
                else:
                    ratio = 0
                    
                return event_count, function_count, round(ratio, 2)
        except:
            return 0, 0, 0
    
    def is_pure_ui_file(self, filepath):
        """检查是否为纯UI文件（级别2）"""
        filename = filepath.name.lower()
        
        # 明确的UI文件名模式
        pure_ui_patterns = [
            'menubar', 'toolbar', 'statusbar',
            'dialog_', 'panel_', 'frame_',
            '_dlg.', '_dialog.', '_panel.',
            'appearance_controls', 'widget'
        ]
        
        for pattern in pure_ui_patterns:
            if pattern in filename:
                # 再检查是否不是base文件（base文件归类到级别1）
                if '_base' not in filename:
                    return True
                    
        return False
    
    def is_resource_file(self, filepath):
        """检查是否为资源文件"""
        resource_extensions = ['.png', '.svg', '.ico', '.jpg', '.jpeg', '.gif', 
                              '.bmp', '.xpm', '.cur', '.ani', '.icns']
        return filepath.suffix.lower() in resource_extensions
    
    def group_related_files(self, all_files):
        """将相关文件分组（如.fbp与其对应的_base.cpp和_base.h）"""
        # 建立文件关联
        fbp_files = {}
        base_files = {}
        normal_files = {}
        
        for filepath in all_files:
            if filepath.suffix == '.fbp':
                base_name = filepath.stem
                fbp_files[base_name] = filepath
            elif '_base' in filepath.stem:
                # 提取基础名称（去掉_base）
                base_name = filepath.stem.replace('_base', '')
                if base_name not in base_files:
                    base_files[base_name] = {}
                base_files[base_name][filepath.suffix] = filepath
            else:
                # 普通文件
                base_name = filepath.stem
                if base_name not in normal_files:
                    normal_files[base_name] = {}
                normal_files[base_name][filepath.suffix] = filepath
        
        # 创建文件组
        groups = []
        
        # 处理fbp相关文件组
        for base_name, fbp_path in fbp_files.items():
            group = [fbp_path]
            if base_name in base_files:
                if '.cpp' in base_files[base_name]:
                    group.append(base_files[base_name]['.cpp'])
                if '.h' in base_files[base_name]:
                    group.append(base_files[base_name]['.h'])
            groups.append(('fbp_group', group))
        
        # 处理其他成对的文件（.cpp和.h）
        processed = set()
        for base_name, files in normal_files.items():
            if base_name not in processed:
                group = []
                if '.cpp' in files:
                    group.append(files['.cpp'])
                if '.h' in files:
                    group.append(files['.h'])
                if len(group) > 0:
                    groups.append(('normal_group', group))
                processed.add(base_name)
        
        return groups
    
    def analyze_files(self):
        """分析所有文件并分类"""
        print(f"正在扫描目录: {self.root_dir}")
        all_files = self.scan_directory()
        print(f"找到 {len(all_files)} 个文件")
        
        # 按文件类型分类
        for filepath in all_files:
            # 跳过非代码文件（除了资源文件）
            if filepath.suffix not in ['.cpp', '.h', '.fbp'] and not self.is_resource_file(filepath):
                continue
            
            # 级别1：自动生成的文件
            if self.is_auto_generated(filepath):
                self.file_groups['level1_auto_generated'].append(filepath)
            
            # 资源文件
            elif self.is_resource_file(filepath):
                self.file_groups['resources'].append(filepath)
            
            # 级别2：纯UI文件
            elif self.is_pure_ui_file(filepath):
                self.file_groups['level2_pure_ui'].append(filepath)
            
            # 级别3：需要内容分析的文件
            elif filepath.suffix in ['.cpp', '.h']:
                analyzed = False
                
                # 3A: 继承关系分析
                inherited_bases = self.check_inheritance(filepath)
                if inherited_bases:
                    self.file_groups['level3_inheritance'].append((filepath, inherited_bases))
                    analyzed = True
                
                # 3B: UI控件密度检查
                ui_count, total_lines, density = self.calculate_ui_density(filepath)
                if density > 5:  # 密度大于5%
                    self.file_groups['level3_ui_density'].append((filepath, ui_count, total_lines, density))
                    analyzed = True
                
                # 3C: 事件处理模式
                event_count, func_count, ratio = self.check_event_handlers(filepath)
                if ratio > 30:  # 事件处理占比大于30%
                    self.file_groups['level3_event_handlers'].append((filepath, event_count, func_count, ratio))
                    analyzed = True
    
    def create_excel_report(self, output_file='ui_files_analysis.xlsx'):
        """创建Excel报告"""
        wb = Workbook()
        
        # 删除默认的sheet
        wb.remove(wb.active)
        
        # 样式定义
        header_font = Font(bold=True, color="FFFFFF")
        header_fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
        header_alignment = Alignment(horizontal="center", vertical="center")
        
        border = Border(
            left=Side(style='thin'),
            right=Side(style='thin'),
            top=Side(style='thin'),
            bottom=Side(style='thin')
        )
        
        # Sheet 1: 级别1 - 自动生成的文件
        ws1 = wb.create_sheet("Level1_自动生成", 0)
        ws1.append(["文件路径"])
        for cell in ws1[1]:
            cell.font = header_font
            cell.fill = header_fill
            cell.alignment = header_alignment
        
        # 收集并组织文件
        fbp_files = {}  # {stem: filepath}
        base_cpp_files = {}  # {stem_without_base: filepath}
        base_h_files = {}  # {stem_without_base: filepath}
        
        for filepath in self.file_groups['level1_auto_generated']:
            if filepath.suffix == '.fbp':
                fbp_files[filepath.stem] = filepath
            elif filepath.name.endswith('_base.cpp'):
                stem = filepath.stem.replace('_base', '')
                base_cpp_files[stem] = filepath
            elif filepath.name.endswith('_base.h'):
                stem = filepath.stem.replace('_base', '')
                base_h_files[stem] = filepath
        
        # 获取所有唯一的基础名称
        all_stems = set(fbp_files.keys()) | set(base_cpp_files.keys()) | set(base_h_files.keys())
        
        # 按名称排序后写入（确保相关文件紧挨着）
        for stem in sorted(all_stems):
            # 写入.fbp文件
            if stem in fbp_files:
                try:
                    ws1.append([str(fbp_files[stem].relative_to(self.root_dir))])
                except:
                    ws1.append([str(fbp_files[stem])])
            
            # 写入对应的_base.cpp文件
            if stem in base_cpp_files:
                try:
                    ws1.append([str(base_cpp_files[stem].relative_to(self.root_dir))])
                except:
                    ws1.append([str(base_cpp_files[stem])])
            
            # 写入对应的_base.h文件
            if stem in base_h_files:
                try:
                    ws1.append([str(base_h_files[stem].relative_to(self.root_dir))])
                except:
                    ws1.append([str(base_h_files[stem])])
        
        # Sheet 2: 级别2 - 纯UI文件
        ws2 = wb.create_sheet("Level2_纯UI文件", 1)
        ws2.append(["文件路径"])
        for cell in ws2[1]:
            cell.font = header_font
            cell.fill = header_fill
            cell.alignment = header_alignment
        
        # 收集所有文件并按目录和基名分组
        file_map = {}
        for filepath in self.file_groups['level2_pure_ui']:
            dir_path = filepath.parent
            base_name = filepath.stem
            key = (dir_path, base_name)
            
            if key not in file_map:
                file_map[key] = {'cpp': None, 'h': None}
            
            if filepath.suffix == '.cpp':
                file_map[key]['cpp'] = filepath
            elif filepath.suffix == '.h':
                file_map[key]['h'] = filepath
        
        # 按目录和名称排序后写入（无空行，成对文件紧挨着）
        for (dir_path, base_name), files in sorted(file_map.items()):
            # 如果有成对的文件，cpp和h紧挨着显示
            if files['cpp'] and files['h']:
                try:
                    ws2.append([str(files['cpp'].relative_to(self.root_dir))])
                    ws2.append([str(files['h'].relative_to(self.root_dir))])
                except:
                    ws2.append([str(files['cpp'])])
                    ws2.append([str(files['h'])])
            # 只有cpp文件
            elif files['cpp']:
                try:
                    ws2.append([str(files['cpp'].relative_to(self.root_dir))])
                except:
                    ws2.append([str(files['cpp'])])
            # 只有h文件
            elif files['h']:
                try:
                    ws2.append([str(files['h'].relative_to(self.root_dir))])
                except:
                    ws2.append([str(files['h'])])
        
        # Sheet 3A: 级别3 - 继承关系分析
        ws3a = wb.create_sheet("Level3A_继承关系", 2)
        ws3a.append(["文件路径", "继承自"])
        for cell in ws3a[1]:
            cell.font = header_font
            cell.fill = header_fill
            cell.alignment = header_alignment
        
        for item in self.file_groups['level3_inheritance']:
            filepath, bases = item
            try:
                ws3a.append([str(filepath.relative_to(self.root_dir)), 
                            ', '.join(bases)])
            except:
                ws3a.append([str(filepath), ', '.join(bases)])
        
        # Sheet 3B: 级别3 - UI控件密度
        ws3b = wb.create_sheet("Level3B_UI密度", 3)
        ws3b.append(["文件路径", "UI关键词数", "总行数", "密度(%)"])
        for cell in ws3b[1]:
            cell.font = header_font
            cell.fill = header_fill
            cell.alignment = header_alignment
        
        for item in self.file_groups['level3_ui_density']:
            filepath, ui_count, total_lines, density = item
            try:
                ws3b.append([str(filepath.relative_to(self.root_dir)), 
                            ui_count, 
                            total_lines, 
                            density])
            except:
                ws3b.append([str(filepath), ui_count, total_lines, density])
        
        # Sheet 3C: 级别3 - 事件处理
        ws3c = wb.create_sheet("Level3C_事件处理", 4)
        ws3c.append(["文件路径", "事件数", "函数数", "事件占比(%)"])
        for cell in ws3c[1]:
            cell.font = header_font
            cell.fill = header_fill
            cell.alignment = header_alignment
        
        for item in self.file_groups['level3_event_handlers']:
            filepath, event_count, func_count, ratio = item
            try:
                ws3c.append([str(filepath.relative_to(self.root_dir)), 
                            event_count, 
                            func_count, 
                            ratio])
            except:
                ws3c.append([str(filepath), event_count, func_count, ratio])
        
        # Sheet 4: 资源文件
        ws4 = wb.create_sheet("资源文件", 5)
        ws4.append(["文件路径"])
        for cell in ws4[1]:
            cell.font = header_font
            cell.fill = header_fill
            cell.alignment = header_alignment
        
        # 按类型分组资源文件
        resource_by_type = {}
        for filepath in self.file_groups['resources']:
            ext = filepath.suffix.lower()
            if ext not in resource_by_type:
                resource_by_type[ext] = []
            resource_by_type[ext].append(filepath)
        
        for ext, files in sorted(resource_by_type.items()):
            ws4.append([f"=== {ext.upper()} 文件 ({len(files)}个) ==="])
            for filepath in files[:100]:  # 限制每种类型最多显示100个
                try:
                    ws4.append([str(filepath.relative_to(self.root_dir))])
                except:
                    ws4.append([str(filepath)])
            if len(files) > 100:
                ws4.append([f"... 还有 {len(files) - 100} 个{ext}文件"])
            ws4.append([])  # 类型间空行
        
        # 添加统计sheet
        ws_stats = wb.create_sheet("统计汇总", 0)
        ws_stats.append(["分类", "文件数量", "说明"])
        for cell in ws_stats[1]:
            cell.font = header_font
            cell.fill = header_fill
            cell.alignment = header_alignment
        
        ws_stats.append(["级别1 - 自动生成", len(self.file_groups['level1_auto_generated']), 
                        "wxFormBuilder生成的文件，100%安全删除"])
        ws_stats.append(["级别2 - 纯UI文件", len(self.file_groups['level2_pure_ui']), 
                        "明确的UI文件（menubar/toolbar/dialog/panel等），较安全删除"])
        ws_stats.append(["级别3A - 继承UI类", len(self.file_groups['level3_inheritance']), 
                        "继承自wxDialog/wxPanel/wxFrame等wx UI基类"])
        ws_stats.append(["级别3B - UI密度高", len(self.file_groups['level3_ui_density']), 
                        "UI控件密度>5%，需要仔细检查"])
        ws_stats.append(["级别3C - 事件处理", len(self.file_groups['level3_event_handlers']), 
                        "事件处理>30%，可能混合业务逻辑"])
        ws_stats.append(["资源文件", len(self.file_groups['resources']), 
                        "PNG/SVG/ICO等图标、图片资源文件"])
        
        # 添加空行
        ws_stats.append([])
        ws_stats.append(["Level3B UI密度检测的关键词包括："])
        ws_stats.append([""])
        ws_stats.append(["wxWidgets控件：", "", "wxButton, wxTextCtrl, wxListBox, wxComboBox, wxCheckBox等"])
        ws_stats.append(["布局相关：", "", "wxSizer, wxBoxSizer, wxFlexGridSizer, SetSizer, Layout等"])
        ws_stats.append(["事件绑定：", "", "EVT_BUTTON, EVT_MENU, EVT_TOOL, EVT_TEXT等"])
        ws_stats.append(["UI函数：", "", "SetTitle, SetIcon, CreateStatusBar, CreateToolBar等"])
        
        ws_stats.append([])
        ws_stats.append(["Level3C 事件处理统计的模式包括："])
        ws_stats.append([""])
        ws_stats.append(["事件表：", "", "BEGIN_EVENT_TABLE, END_EVENT_TABLE"])
        ws_stats.append(["事件绑定：", "", "EVT_* 系列宏（EVT_MENU, EVT_BUTTON, EVT_CLOSE等）"])
        ws_stats.append(["动态连接：", "", "Connect(wxEVT_*), Bind(wxEVT_*)"])
        ws_stats.append(["事件占比：", "", "事件处理函数数量 / 总函数数量 * 100%"])
        
        # 调整列宽
        for ws in wb.worksheets:
            for column in ws.columns:
                max_length = 0
                column_letter = get_column_letter(column[0].column)
                for cell in column:
                    try:
                        if len(str(cell.value)) > max_length:
                            max_length = len(str(cell.value))
                    except:
                        pass
                adjusted_width = min(max_length + 2, 100)
                ws.column_dimensions[column_letter].width = adjusted_width
        
        # 保存文件
        wb.save(output_file)
        print(f"\nExcel report generated: {output_file}")
        
        # 打印统计信息
        print("\nStatistics:")
        print(f"  Level 1 (Auto-generated): {len(self.file_groups['level1_auto_generated'])} files")
        print(f"  Level 2 (Pure UI): {len(self.file_groups['level2_pure_ui'])} files")
        print(f"  Level 3A (Inheritance): {len(self.file_groups['level3_inheritance'])} files")
        print(f"  Level 3B (UI Density): {len(self.file_groups['level3_ui_density'])} files")
        print(f"  Level 3C (Event Handlers): {len(self.file_groups['level3_event_handlers'])} files")
        print(f"  Resources: {len(self.file_groups['resources'])} files")

def main():
    """主函数"""
    import argparse
    
    parser = argparse.ArgumentParser(description='分析KiCad UI文件并输出到Excel')
    parser.add_argument('directory', nargs='?', default='.', 
                       help='要分析的目录路径（默认为当前目录）')
    parser.add_argument('-o', '--output', default='ui_files_analysis.xlsx',
                       help='输出的Excel文件名（默认为ui_files_analysis.xlsx）')
    
    args = parser.parse_args()
    
    # 检查目录是否存在
    if not os.path.exists(args.directory):
        print(f"错误: 目录 {args.directory} 不存在")
        sys.exit(1)
    
    # 检查是否安装了openpyxl
    try:
        import openpyxl
    except ImportError:
        print("错误: 需要安装openpyxl库")
        print("请运行: pip install openpyxl")
        sys.exit(1)
    
    # 执行分析
    analyzer = UIFileAnalyzer(args.directory)
    analyzer.analyze_files()
    analyzer.create_excel_report(args.output)
    
    print(f"\n分析完成! 请查看 {args.output} 文件")
    print("\n说明:")
    print("  - Level1: 可以安全删除的自动生成文件")
    print("  - Level2: 较安全删除的纯UI文件")
    print("  - Level3A/B/C: 需要谨慎检查的混合文件")
    print("  - 资源文件: PNG/SVG/ICO等图标资源")

if __name__ == '__main__':
    main()