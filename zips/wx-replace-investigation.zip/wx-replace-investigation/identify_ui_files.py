#!/usr/bin/env python3
"""
KiCad 纯UI文件识别脚本
识别并分类所有纯UI相关的文件，包括自动生成的和手写的UI文件
"""

import os
import re
import glob
import json
from pathlib import Path

def find_files(pattern, exclude_dirs=None):
    """查找匹配模式的文件"""
    if exclude_dirs is None:
        exclude_dirs = {'build', 'Debug', 'Release', '.git', 'thirdparty'}
    
    files = []
    for root, dirs, filenames in os.walk('.'):
        # 排除不需要的目录
        dirs[:] = [d for d in dirs if d not in exclude_dirs]
        
        for filename in filenames:
            if any(fnmatch(filename, p) for p in pattern if isinstance(pattern, list)):
                files.append(os.path.join(root, filename))
            elif isinstance(pattern, str) and fnmatch(filename, pattern):
                files.append(os.path.join(root, filename))
    return files

def fnmatch(filename, pattern):
    """简单的文件名匹配"""
    import fnmatch as fm
    return fm.fnmatch(filename, pattern)

def is_auto_generated_ui_file(filepath):
    """检查文件是否为自动生成的UI文件"""
    try:
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read(2000)  # 只读前2000字符
            return (
                'C++ code generated with wxFormBuilder' in content or
                'PLEASE DO *NOT* EDIT THIS FILE!' in content
            )
    except:
        return False

def is_ui_dialog_panel_file(filepath):
    """检查文件是否为UI对话框/面板文件"""
    if not filepath.endswith(('.cpp', '.h')):
        return False
        
    try:
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read(5000)  # 读前5000字符
            
            # 检查类继承关系
            ui_base_classes = [
                r'class\s+\w+\s*:\s*public\s+.*wxDialog',
                r'class\s+\w+\s*:\s*public\s+.*wxPanel', 
                r'class\s+\w+\s*:\s*public\s+.*wxFrame',
                r'class\s+\w+\s*:\s*public\s+.*DIALOG_\w+_BASE',
                r'class\s+\w+\s*:\s*public\s+.*PANEL_\w+_BASE'
            ]
            
            for pattern in ui_base_classes:
                if re.search(pattern, content):
                    return True
            
            return False
    except:
        return False

def is_ui_menu_toolbar_file(filepath):
    """检查文件是否为菜单/工具栏相关文件"""
    filename = os.path.basename(filepath)
    ui_patterns = [
        'menubar', 'toolbar', 'menu.cpp', 'menu.h'
    ]
    
    for pattern in ui_patterns:
        if pattern in filename.lower():
            return True
    
    # 检查文件内容
    try:
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read(3000)
            ui_indicators = [
                'wxMenuBar', 'wxToolBar', 'wxMenu', 'wxMenuItem',
                'EVT_MENU', 'EVT_TOOL', 'AddTool', 'AppendMenu'
            ]
            
            count = sum(1 for indicator in ui_indicators if indicator in content)
            return count >= 3  # 如果包含3个或更多UI相关关键词
    except:
        return False

def is_canvas_view_file(filepath):
    """检查文件是否为画布/视图相关文件"""
    filename = os.path.basename(filepath).lower()
    
    # 文件名模式匹配
    canvas_patterns = [
        'canvas', 'view', 'draw_panel', 'preview', 'viewer'
    ]
    
    for pattern in canvas_patterns:
        if pattern in filename:
            return True
    
    # 检查文件内容中的关键词
    try:
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read(3000)
            canvas_indicators = [
                'wxScrolledCanvas', 'EDA_DRAW_PANEL', 'GAL_DISPLAY_OPTIONS',
                'VIEW_CONTROLS', 'KIGFX::VIEW', 'PCB_DRAW_PANEL',
                'SCH_DRAW_PANEL', 'PREVIEW_PANEL'
            ]
            
            count = sum(1 for indicator in canvas_indicators if indicator in content)
            return count >= 2
    except:
        return False

def is_print_plot_file(filepath):
    """检查文件是否为打印/绘图相关文件"""
    filename = os.path.basename(filepath).lower()
    
    # 文件名模式匹配
    if any(pattern in filename for pattern in ['print', 'plot', 'plotter']):
        return True
    
    # 检查文件内容
    try:
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read(3000)
            print_indicators = [
                'BOARD_PRINTOUT', 'SCH_PRINTOUT', 'wxPrintout',
                'PLOTTER', 'PlotSettings', 'DIALOG_PLOT',
                'DIALOG_PRINT', 'PlotFormat'
            ]
            
            count = sum(1 for indicator in print_indicators if indicator in content)
            return count >= 2
    except:
        return False

def is_settings_options_file(filepath):
    """检查文件是否为设置/选项相关文件"""
    filename = os.path.basename(filepath).lower()
    
    # 文件名模式匹配
    settings_patterns = [
        'settings', 'options', 'preferences', 'config'
    ]
    
    for pattern in settings_patterns:
        if pattern in filename:
            return True
    
    # 检查文件内容
    try:
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read(3000)
            settings_indicators = [
                'APP_SETTINGS', 'COLOR_SETTINGS', 'DISPLAY_OPTIONS',
                'PANEL_.*_OPTIONS', 'DIALOG_.*_SETTINGS',
                'wxPreferencesPage', 'SETTINGS_MANAGER'
            ]
            
            import re
            count = sum(1 for indicator in settings_indicators 
                       if re.search(indicator, content))
            return count >= 2
    except:
        return False

def is_bitmap_related_file(filepath):
    """检查文件是否为位图相关代码文件"""
    filename = os.path.basename(filepath).lower()
    
    if 'bitmap' in filename or 'icon' in filename:
        return True
    
    try:
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read(2000)
            bitmap_indicators = [
                'BITMAP_', 'wxBitmap', 'bitmap_store', 'bitmaps.h',
                'INDICATOR_ICON', 'BITMAP_BUTTON'
            ]
            
            count = sum(1 for indicator in bitmap_indicators if indicator in content)
            return count >= 2
    except:
        return False

def has_only_ui_event_handlers(filepath):
    """检查文件是否只包含UI事件处理代码"""
    try:
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
            
            # 查找事件表
            if 'BEGIN_EVENT_TABLE' in content and 'END_EVENT_TABLE' in content:
                # 统计UI事件 vs 业务逻辑函数
                ui_events = len(re.findall(r'EVT_(MENU|TOOL|BUTTON|CLOSE|SIZE)', content))
                total_functions = len(re.findall(r'^\s*\w+::\w+\s*\(', content, re.MULTILINE))
                
                # 如果UI事件占主导地位（超过70%）
                if total_functions > 0 and ui_events / total_functions > 0.7:
                    return True
            
            return False
    except:
        return False

def analyze_ui_files():
    """分析并分类所有UI文件"""
    print("正在分析KiCad UI文件...")
    
    results = {
        'auto_generated': {
            'fbp_files': [],          # wxFormBuilder项目文件
            'base_cpp_files': [],     # 自动生成的.cpp文件
            'base_h_files': []        # 自动生成的.h文件
        },
        'manual_ui': {
            'dialog_panel_files': [], # 手写的对话框/面板文件
            'menubar_files': [],      # 菜单栏文件
            'toolbar_files': [],      # 工具栏文件
            'event_handler_files': [], # 主要是事件处理的文件
            'canvas_view_files': [],  # 画布/视图相关文件
            'print_plot_files': [],   # 打印/绘图相关文件
            'settings_options_files': [] # 设置/选项相关文件
        },
        'ui_resources': {
            'png_files': [],          # PNG图标文件
            'svg_files': [],          # SVG矢量图文件
            'ico_files': [],          # ICO图标文件
            'bitmap_cpp_files': []    # 位图相关代码文件
        },
        'statistics': {}
    }
    
    # 1. 查找自动生成的UI文件
    print("1. 查找自动生成的UI文件...")
    
    # FBP文件
    fbp_files = find_files('*.fbp')
    results['auto_generated']['fbp_files'] = fbp_files
    
    # 自动生成的base文件
    base_files = find_files(['*_base.cpp', '*_base.h'])
    for filepath in base_files:
        if is_auto_generated_ui_file(filepath):
            if filepath.endswith('.cpp'):
                results['auto_generated']['base_cpp_files'].append(filepath)
            else:
                results['auto_generated']['base_h_files'].append(filepath)
    
    # 2. 查找UI资源文件
    print("2. 查找UI资源文件...")
    
    # PNG文件
    results['ui_resources']['png_files'] = find_files('*.png')
    
    # SVG文件  
    results['ui_resources']['svg_files'] = find_files('*.svg')
    
    # ICO文件
    results['ui_resources']['ico_files'] = find_files('*.ico')
    
    # 3. 查找手写的UI文件
    print("3. 查找手写的UI文件...")
    
    # 所有.cpp和.h文件
    cpp_h_files = find_files(['*.cpp', '*.h'])
    
    for filepath in cpp_h_files:
        # 跳过已经分类的自动生成文件
        if filepath in results['auto_generated']['base_cpp_files'] or \
           filepath in results['auto_generated']['base_h_files']:
            continue
        
        classified = False
        
        # 检查是否为UI对话框/面板文件
        if is_ui_dialog_panel_file(filepath):
            results['manual_ui']['dialog_panel_files'].append(filepath)
            classified = True
        
        # 检查是否为菜单/工具栏文件
        elif is_ui_menu_toolbar_file(filepath):
            filename = os.path.basename(filepath).lower()
            if 'menubar' in filename or 'menu' in filename:
                results['manual_ui']['menubar_files'].append(filepath)
            else:
                results['manual_ui']['toolbar_files'].append(filepath)
            classified = True
        
        # 检查是否为画布/视图文件
        elif is_canvas_view_file(filepath):
            results['manual_ui']['canvas_view_files'].append(filepath)
            classified = True
        
        # 检查是否为打印/绘图文件
        elif is_print_plot_file(filepath):
            results['manual_ui']['print_plot_files'].append(filepath)
            classified = True
        
        # 检查是否为设置/选项文件
        elif is_settings_options_file(filepath):
            results['manual_ui']['settings_options_files'].append(filepath)
            classified = True
        
        # 检查是否为位图相关文件
        elif is_bitmap_related_file(filepath):
            results['ui_resources']['bitmap_cpp_files'].append(filepath)
            classified = True
        
        # 检查是否主要包含UI事件处理
        elif has_only_ui_event_handlers(filepath):
            results['manual_ui']['event_handler_files'].append(filepath)
            classified = True
    
    # 4. 统计信息
    stats = results['statistics']
    stats['fbp_files'] = len(results['auto_generated']['fbp_files'])
    stats['auto_base_cpp'] = len(results['auto_generated']['base_cpp_files'])
    stats['auto_base_h'] = len(results['auto_generated']['base_h_files'])
    stats['manual_dialogs'] = len(results['manual_ui']['dialog_panel_files'])
    stats['manual_menus'] = len(results['manual_ui']['menubar_files'])
    stats['manual_toolbars'] = len(results['manual_ui']['toolbar_files'])
    stats['canvas_views'] = len(results['manual_ui']['canvas_view_files'])
    stats['print_plots'] = len(results['manual_ui']['print_plot_files'])
    stats['settings_options'] = len(results['manual_ui']['settings_options_files'])
    stats['event_handlers'] = len(results['manual_ui']['event_handler_files'])
    stats['png_files'] = len(results['ui_resources']['png_files'])
    stats['svg_files'] = len(results['ui_resources']['svg_files'])
    stats['ico_files'] = len(results['ui_resources']['ico_files'])
    stats['bitmap_code_files'] = len(results['ui_resources']['bitmap_cpp_files'])
    
    total_auto = stats['fbp_files'] + stats['auto_base_cpp'] + stats['auto_base_h']
    total_manual = (stats['manual_dialogs'] + stats['manual_menus'] + stats['manual_toolbars'] + 
                   stats['canvas_views'] + stats['print_plots'] + stats['settings_options'] + 
                   stats['event_handlers'] + stats['bitmap_code_files'])
    total_resources = stats['png_files'] + stats['svg_files'] + stats['ico_files']
    
    stats['total_auto_generated'] = total_auto
    stats['total_manual_ui'] = total_manual
    stats['total_ui_resources'] = total_resources
    stats['total_ui_files'] = total_auto + total_manual + total_resources
    
    return results

def print_results(results):
    """打印分析结果"""
    stats = results['statistics']
    
    print("\n" + "="*60)
    print("KiCad UI文件分析结果")
    print("="*60)
    
    print(f"\n📊 统计概览:")
    print(f"  自动生成文件总数: {stats['total_auto_generated']}")
    print(f"    - .fbp 项目文件: {stats['fbp_files']}")
    print(f"    - _base.cpp 文件: {stats['auto_base_cpp']}")
    print(f"    - _base.h 文件: {stats['auto_base_h']}")
    
    print(f"\n  手写UI文件总数: {stats['total_manual_ui']}")
    print(f"    - 对话框/面板文件: {stats['manual_dialogs']}")
    print(f"    - 菜单栏文件: {stats['manual_menus']}")
    print(f"    - 工具栏文件: {stats['manual_toolbars']}")
    print(f"    - 事件处理文件: {stats['event_handlers']}")
    
    print(f"\n🎯 可安全删除的文件:")
    print(f"  总计: {stats['total_ui_files']} 个文件")
    
    # 分类显示部分文件
    print(f"\n📁 自动生成文件示例 (前10个):")
    for i, f in enumerate(results['auto_generated']['fbp_files'][:10]):
        print(f"  {f}")
    if len(results['auto_generated']['fbp_files']) > 10:
        print(f"  ... 还有 {len(results['auto_generated']['fbp_files']) - 10} 个文件")
    
    print(f"\n📁 手写UI文件示例 (前10个):")
    all_manual = (results['manual_ui']['dialog_panel_files'] + 
                  results['manual_ui']['menubar_files'] + 
                  results['manual_ui']['toolbar_files'])
    for i, f in enumerate(all_manual[:10]):
        print(f"  {f}")
    if len(all_manual) > 10:
        print(f"  ... 还有 {len(all_manual) - 10} 个文件")

def save_results(results, filename='ui_files_analysis.json'):
    """保存结果到JSON文件"""
    with open(filename, 'w', encoding='utf-8') as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    print(f"\n💾 详细结果已保存到: {filename}")

def generate_delete_script(results):
    """生成删除脚本"""
    script_content = """#!/bin/bash
# KiCad UI文件删除脚本
# 警告: 执行此脚本将删除所有UI相关文件!

echo "警告: 此脚本将删除所有KiCad UI文件!"
echo "删除后KiCad将无法运行图形界面，只保留核心功能。"
read -p "确定要继续吗? (输入 YES 确认): " confirm

if [ "$confirm" != "YES" ]; then
    echo "操作已取消"
    exit 1
fi

echo "开始删除UI文件..."

"""
    
    # 添加自动生成文件删除命令
    script_content += "\n# 删除自动生成的UI文件\n"
    all_auto_files = (results['auto_generated']['fbp_files'] + 
                      results['auto_generated']['base_cpp_files'] + 
                      results['auto_generated']['base_h_files'])
    
    for filepath in all_auto_files:
        script_content += f'rm -f "{filepath}"\n'
    
    # 添加手写UI文件删除命令（可选）
    script_content += "\n# 删除手写的UI文件（可选，取消注释以启用）\n"
    all_manual_files = (results['manual_ui']['dialog_panel_files'] + 
                        results['manual_ui']['menubar_files'] + 
                        results['manual_ui']['toolbar_files'] + 
                        results['manual_ui']['event_handler_files'])
    
    for filepath in all_manual_files:
        script_content += f'# rm -f "{filepath}"\n'
    
    script_content += '\necho "UI文件删除完成!"\n'
    
    with open('delete_ui_files.sh', 'w') as f:
        f.write(script_content)
    
    # 生成Windows批处理文件
    bat_content = script_content.replace('#!/bin/bash', '@echo off').replace('rm -f', 'del /f').replace('#', 'REM')
    with open('delete_ui_files.bat', 'w') as f:
        f.write(bat_content)
    
    print(f"🗑️ 删除脚本已生成:")
    print(f"  Linux/macOS: delete_ui_files.sh")
    print(f"  Windows: delete_ui_files.bat")

if __name__ == '__main__':
    # 确保在KiCad根目录运行
    if not os.path.exists('CMakeLists.txt'):
        print("错误: 请在KiCad根目录运行此脚本")
        exit(1)
    
    # 执行分析
    results = analyze_ui_files()
    
    # 显示结果
    print_results(results)
    
    # 保存结果
    save_results(results)
    
    # 生成删除脚本
    generate_delete_script(results)
    
    print("\n✅ 分析完成! 现在你可以:")
    print("  1. 查看 ui_files_analysis.json 获取详细信息")
    print("  2. 运行 delete_ui_files.sh (Linux/macOS) 或 delete_ui_files.bat (Windows) 删除UI文件")
    print("  3. 只删除 .fbp 文件 (最安全的选择)")