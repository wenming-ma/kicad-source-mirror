#!/usr/bin/env python3
"""
KiCad wxWidgets Usage Finder - JSONL Output Version
扫描KiCad源码中所有非UI相关wx功能的使用情况，输出到JSONL文件
每行一个文件的结果
"""

import os
import re
import json
import time
from pathlib import Path
from collections import defaultdict
from typing import Dict, List, Set, Tuple

class WxUsageFinderJSONL:
    def __init__(self, source_dir: str):
        self.source_dir = Path(source_dir)
        
        # 定义要搜索的wx关键字模式（非UI相关）
        self.wx_patterns = {
            # 基础数据类型
            'basic_types': [
                r'\bwxString\b',
                r'\bwxArrayString\b', 
                r'\bwxFileName\b',
                r'\bwxVariant\b',
                r'\bwxAny\b',
                r'\bwxBase64\w*\b'
            ],
            
            # 几何和数学
            'geometry': [
                r'\bwxPoint\b',
                r'\bwxRealPoint\b',
                r'\bwxPoint2D\b',
                r'\bwxSize\b',
                r'\bwxRect\b',
                r'\bwxRegion\b',
                r'\bwxCoord\b'
            ],
            
            # 时间和定时器
            'time': [
                r'\bwxDateTime\b',
                r'\bwxTimer\b',
                r'\bwxTimerEvent\b',
                r'\bwxStopWatch\b',
                r'\bwxGetLocalTime\b'
            ],
            
            # 文件和路径
            'file_path': [
                r'\bwxDir\b',
                r'\bwxFile\b',
                r'\bwxTextFile\b',
                r'\bwxStandardPaths\b'
            ],
            
            # 容器和集合
            'containers': [
                r'\bwxArrayInt\b',
                r'\bwxList\b',
                r'\bwxObjectList\b',
                r'\bwxHashMap\b',
                r'\bwxHashSet\b',
                r'\bwxSortedArray\b'
            ],
            
            # 流和序列化
            'streams': [
                r'\bwxInputStream\b',
                r'\bwxOutputStream\b',
                r'\bwxFileInputStream\b',
                r'\bwxFileOutputStream\b',
                r'\bwxMemoryInputStream\b',
                r'\bwxMemoryOutputStream\b',
                r'\bwxTextInputStream\b',
                r'\bwxTextOutputStream\b',
                r'\bwxDataInputStream\b',
                r'\bwxDataOutputStream\b',
                r'\bwxStreamBuffer\b'
            ],
            
            # 压缩和归档
            'archive': [
                r'\bwxZipInputStream\b',
                r'\bwxZipOutputStream\b',
                r'\bwxZipEntry\b',
                r'\bwxArchiveEntry\b'
            ],
            
            # 网络和通信
            'network': [
                r'\bwxSocket\b',
                r'\bwxSocketBase\b',
                r'\bwxURL\b',
                r'\bwxURI\b'
            ],
            
            # 多线程
            'threading': [
                r'\bwxThread\b',
                r'\bwxThreadEvent\b',
                r'\bwxCriticalSection\b',
                r'\bwxMutex\b',
                r'\bwxSemaphore\b',
                r'\bwxCondition\b'
            ],
            
            # XML处理
            'xml': [
                r'\bwxXmlDocument\b',
                r'\bwxXmlNode\b'
            ],
            
            # 配置管理
            'config': [
                r'\bwxConfig\b',
                r'\bwxConfigBase\b',
                r'\bwxFileConfig\b',
                r'\bwxRegConfig\b'
            ],
            
            # 系统集成
            'system': [
                r'\bwxSystemSettings\b',
                r'\bwxSystemAppearance\b',
                r'\bwxPlatformInfo\b',
                r'\bwxOperatingSystemId\b'
            ],
            
            # 日志系统
            'logging': [
                r'\bwxLogTrace\b',
                r'\bwxLogMessage\b',
                r'\bwxLogError\b',
                r'\bwxLogWarning\b',
                r'\bwxLogDebug\b',
                r'\bwxLogVerbose\b',
                r'\bwxLogNull\b'
            ],
            
            # 进程管理
            'process': [
                r'\bwxExecute\b',
                r'\bwxProcess\b'
            ],
            
            # 剪贴板和拖拽
            'clipboard': [
                r'\bwxClipboard\b',
                r'\bwxDropTarget\b',
                r'\bwxDropSource\b',
                r'\bwxDataObject\b'
            ],
            
            # 应用程序框架
            'app_framework': [
                r'\bwxApp\b',
                r'\bwxAppConsole\b',
                r'\bwxCmdLineParser\b',
                r'\bwxCmdLineEntryDesc\b'
            ],
            
            # 调试支持
            'debug': [
                r'\bwxASSERT\b',
                r'\bwxCHECK_MSG\b'
            ],
            
            # 单实例管理
            'singleton': [
                r'\bwxSingleInstanceChecker\b'
            ],
            
            # 事件系统
            'events': [
                r'\bwxDEFINE_EVENT\b',
                r'\bwxDECLARE_EVENT\b',
                r'\bwxEVT_\w+\b'
            ],
            
            # MIME和媒体
            'mime': [
                r'\bwxMimeTypesManager\b'
            ],
            
            # 验证器
            'validators': [
                r'\bwxTextValidator\b'
            ],
            
            # 国际化
            'i18n': [
                r'\bwxTranslation\b',
                r'\bwxLocale\b'
            ],
            
            # 正则表达式
            'regex': [
                r'\bwxRegEx\b'
            ],
            
            # 常用宏和常量
            'macros': [
                r'\bwxEmptyString\b',
                r'\bwxDefaultPosition\b',
                r'\bwxDefaultSize\b',
                r'\bwxID_ANY\b',
                r'\bwxFileSelectorDefaultWildcardStr\b',
                r'\bBEGIN_EVENT_TABLE\b',
                r'\bEND_EVENT_TABLE\b'
            ]
        }
        
        # 文件扩展名过滤
        self.file_extensions = {'.cpp', '.h', '.hpp', '.cc', '.cxx', '.c'}
        
        # 排除的目录
        self.exclude_dirs = {'.git', 'build', 'cmake', 'Documentation', 'demos', 'resources'}
    
    def should_process_file(self, file_path: Path) -> bool:
        """判断是否应该处理该文件"""
        # 检查文件扩展名
        if file_path.suffix.lower() not in self.file_extensions:
            return False
            
        # 检查是否在排除目录中
        for part in file_path.parts:
            if part in self.exclude_dirs:
                return False
                
        return True
    
    def search_in_file(self, file_path: Path) -> Dict[str, Set[str]]:
        """在单个文件中搜索wx模式，返回匹配的模式名称"""
        matches = defaultdict(set)
        
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
                
            for category, patterns in self.wx_patterns.items():
                for pattern in patterns:
                    if re.search(pattern, content):
                        # 提取实际匹配的wx元素名称
                        found_matches = re.findall(pattern, content)
                        for match in found_matches:
                            matches[category].add(match)
                            
        except Exception as e:
            print(f"Error reading {file_path}: {e}")
            
        return {k: list(v) for k, v in matches.items()}
    
    def scan_directory_to_jsonl(self, output_file: str) -> None:
        """扫描整个目录并输出到JSONL文件"""
        print(f"Scanning directory: {self.source_dir}")
        
        # 统计总文件数
        all_files = [f for f in self.source_dir.rglob('*') 
                     if f.is_file() and self.should_process_file(f)]
        total_files = len(all_files)
        print(f"Found {total_files} files to process")
        
        start_time = time.time()
        file_count = 0
        files_with_wx = 0
        
        with open(output_file, 'w', encoding='utf-8') as outfile:
            for file_path in all_files:
                file_count += 1
                
                # 进度显示
                if file_count % 100 == 0:
                    elapsed = time.time() - start_time
                    progress = (file_count / total_files) * 100
                    speed = file_count / elapsed if elapsed > 0 else 0
                    eta = (total_files - file_count) / speed if speed > 0 else 0
                    print(f"Progress: {file_count}/{total_files} ({progress:.1f}%) "
                          f"Speed: {speed:.1f} files/s ETA: {eta:.0f}s")
                
                matches = self.search_in_file(file_path)
                
                if matches:
                    files_with_wx += 1
                    rel_path = str(file_path.relative_to(self.source_dir))
                    
                    # 创建JSONL记录
                    record = {
                        'file': rel_path,
                        'wx_elements': matches
                    }
                    
                    # 写入JSONL文件
                    outfile.write(json.dumps(record, ensure_ascii=False) + '\n')
        
        elapsed = time.time() - start_time
        print(f"\nCompleted scanning {file_count} files in {elapsed:.1f} seconds")
        print(f"Found {files_with_wx} files with wx usage")
        print(f"Results saved to: {output_file}")

def main():
    """主函数"""
    # 配置路径
    source_dir = "."  # 当前目录
    output_file = "wx_usage_results.jsonl"
    
    # 创建查找器实例
    finder = WxUsageFinderJSONL(source_dir)
    
    # 扫描目录并输出到JSONL
    finder.scan_directory_to_jsonl(output_file)
    
    print(f"\nDone! Check {output_file} for results.")
    print("Each line contains one file's wx usage data in JSON format.")

if __name__ == "__main__":
    main()