# KiCad wxWidgets 非UI功能替换映射表

本文档列出了KiCad中使用的所有非UI相关的wxWidgets功能，按功能类别组织，提供完整的替换参考。

## 1. 字符串和数据类型

### 核心字符串类型
- `wxString` - Unicode字符串类
- `wxArrayString` - 字符串数组
- `wxStringTokenize()` - 字符串分词

### 数据容器
- `wxVariant` - 通用数据容器
- `wxAny` - 类型安全的通用容器
- `wxBase64Encode/Decode()` - Base64编码解码

## 2. 文件和路径操作

### 文件路径处理
- `wxFileName` - 文件名和路径操作类
- `wxFileName::Assign()` - 路径赋值
- `wxFileName::GetFullPath()` - 获取完整路径
- `wxFileName::FileExists()` - 文件存在检查
- `wxFileName::DirExists()` - 目录存在检查
- `wxFileName::GetPathSeparator()` - 获取路径分隔符

### 目录操作
- `wxDir` - 目录操作类
- `wxDir::Exists()` - 目录存在检查
- `wxDir::GetFirst()` - 获取第一个文件/目录
- `wxDir::GetNext()` - 获取下一个文件/目录

### 标准路径
- `wxStandardPaths` - 标准系统路径
- `wxStandardPaths::Get()` - 获取实例
- `wxStandardPaths::GetExecutablePath()` - 可执行文件路径

### 文件操作
- `wxFile` - 文件操作类
- `wxTextFile` - 文本文件操作

## 3. 时间和日期功能

### 时间处理
- `wxDateTime` - 日期时间类
- `wxDateTime::Now()` - 获取当前时间
- `wxDateTime::FormatISOCombined()` - ISO格式化

### 定时器
- `wxTimer` - 定时器类
- `wxTimerEvent` - 定时器事件
- `wxTimerEventHandler()` - 定时器事件处理器

### 时间测量
- `wxStopWatch` - 秒表计时器
- `wxGetLocalTime()` - 获取本地时间

## 4. 几何和数学

### 基础几何类型
- `wxPoint` - 2D整数坐标点
- `wxRealPoint` - 2D浮点坐标点
- `wxPoint2D` - 高精度2D坐标
- `wxSize` - 尺寸(宽度x高度)
- `wxRect` - 矩形区域
- `wxRegion` - 区域形状
- `wxCoord` - 坐标值类型

## 5. 容器和集合

### 数组类型
- `wxArrayString` - 字符串数组
- `wxArrayInt` - 整数数组
- `wxSortedArray` - 排序数组

### 列表和映射
- `wxList` - 链表
- `wxObjectList` - 对象链表
- `wxHashMap` - 哈希映射
- `wxHashSet` - 哈希集合

## 6. 流和序列化

### 输入流
- `wxInputStream` - 输入流基类
- `wxFileInputStream` - 文件输入流
- `wxMemoryInputStream` - 内存输入流
- `wxTextInputStream` - 文本输入流
- `wxDataInputStream` - 数据输入流

### 输出流
- `wxOutputStream` - 输出流基类
- `wxFileOutputStream` - 文件输出流
- `wxMemoryOutputStream` - 内存输出流
- `wxTextOutputStream` - 文本输出流
- `wxDataOutputStream` - 数据输出流

### 流缓冲区
- `wxStreamBuffer` - 流缓冲区
- `wxFileOutputStreamWithProgress` - 带进度的文件输出流

## 7. 压缩和归档 ⭐

### ZIP支持
- `wxZipInputStream` - ZIP输入流
- `wxZipOutputStream` - ZIP输出流
- `wxZipEntry` - ZIP条目
- `wxArchiveEntry` - 通用归档条目接口

## 8. 网络和通信

### Socket通信
- `wxSocket` - Socket基类
- `wxSocketBase` - Socket基础功能
- TCP/IP端口常量:
  - `KICAD_PCB_PORT_SERVICE_NUMBER` (4242)
  - `KICAD_SCH_PORT_SERVICE_NUMBER` (4243)  
  - `KICAD_PY_PORT_SERVICE_NUMBER` (4244)

### URL处理
- `wxURL` - URL解析和访问
- `wxURI` - URI解析

## 9. 多线程和并发

### 线程管理
- `wxThread` - 线程类
- `wxTHREAD_JOINABLE` - 可等待线程模式
- `wxThread::ExitCode` - 线程退出码

### 线程事件
- `wxThreadEvent` - 线程事件
- `wxEVT_THREAD_STDIN` - 标准输入事件
- `wxEVT_THREAD_STDERR` - 标准错误事件

### 同步原语
- `wxCriticalSection` - 临界区
- `wxMutex` - 互斥锁
- `wxSemaphore` - 信号量
- `wxCondition` - 条件变量

## 10. XML处理

### XML解析
- `wx/xml/xml.h` - XML解析头文件
- `wxXmlDocument` - XML文档类
- `wxXmlNode` - XML节点类

## 11. 配置和设置

### 配置基类
- `wxConfigBase` - 配置基类
- `wxConfig` - 通用配置类
- `wxFileConfig` - 文件配置
- `wxRegConfig` - 注册表配置(Windows)

## 12. 系统集成

### 系统设置
- `wxSystemSettings` - 系统设置
- `wxSystemSettings::GetMetric()` - 获取度量
- `wxSystemSettings::GetFont()` - 获取系统字体
- `wxSystemSettings::GetColour()` - 获取系统颜色
- `wxSystemAppearance` - 系统外观检测

### 系统信息
- `wxPlatformInfo` - 平台信息
- `wxOperatingSystemId` - 操作系统ID

## 13. 日志系统

### 日志类型
- `wxLogTrace()` - 跟踪日志
- `wxLogMessage()` - 消息日志
- `wxLogError()` - 错误日志
- `wxLogWarning()` - 警告日志
- `wxLogDebug()` - 调试日志
- `wxLogVerbose()` - 详细日志
- `wxLogNull` - 禁用日志

## 14. 进程和执行

### 进程管理
- `wxExecute()` - 执行外部程序
- `wxProcess` - 进程类

## 15. 剪贴板和数据传输

### 剪贴板
- `wxClipboard` - 剪贴板访问

### 拖拽操作
- `wxDropTarget` - 拖拽目标
- `wxDropSource` - 拖拽源
- `wxDataObject` - 数据对象

## 16. 应用程序框架 ⭐

### 控制台应用
- `wxAppConsole` - 控制台应用基类
- `wxApp` - 应用程序基类

### 命令行处理
- `wxCmdLineParser` - 命令行解析器
- `wxCmdLineEntryDesc` - 命令行参数描述

## 17. 调试和断言 ⭐

### 调试支持
- `wx/debug.h` - 调试头文件
- `wxASSERT()` - 断言宏
- `wxCHECK_MSG()` - 检查消息宏

## 18. 单实例管理 ⭐

### 单实例检查
- `wxSingleInstanceChecker` - 单实例检查器

## 19. 事件系统(非UI)

### 自定义事件宏
- `wxDEFINE_EVENT()` - 定义事件宏
- `wxDECLARE_EVENT()` - 声明事件宏

### 常用自定义事件
- `wxEVT_REFRESH_CUSTOM_COMMAND` - 刷新命令事件
- `KIEVT_SHOW_INFOBAR` - 显示信息栏事件
- `KIEVT_DISMISS_INFOBAR` - 关闭信息栏事件
- `EDA_EVT_LISTBOX_COPY` - 列表框复制事件
- `EVT_LIBITEM_SELECTED` - 库项目选择事件
- `API_REQUEST_EVENT` - API请求事件

## 20. 媒体和MIME

### MIME类型
- `wxMimeTypesManager` - MIME类型管理器

## 21. 输入验证

### 验证器
- `wxTextValidator` - 文本验证器

## 22. 国际化

### 翻译系统
- `wxTranslation` - 翻译管理
- `wxLocale` - 本地化设置

## 23. 正则表达式

### 模式匹配
- `wxRegEx` - 正则表达式类

## 24. 实用工具

### 系统工具
- `wx/utils.h` - 实用函数头文件
- 各种系统级实用函数

### 图像处理(非UI核心)
- `wx/rawbmp.h` - 原始位图数据访问

## 25. 宏和常量

### 常用宏
- `wxEmptyString` - 空字符串常量
- `wxDefaultPosition` - 默认位置
- `wxDefaultSize` - 默认尺寸
- `wxID_ANY` - 任意ID
- `wxFileSelectorDefaultWildcardStr` - 默认文件通配符

### 事件表宏
- `BEGIN_EVENT_TABLE()` - 开始事件表
- `END_EVENT_TABLE()` - 结束事件表
- `EVT_*()` - 各种事件映射宏

## 使用说明

1. 此映射表列出了KiCad中实际使用的所有非UI相关wxWidgets功能
2. 标记为⭐的类别是经过深度分析发现的重要功能
3. 每个功能都包含了在KiCad源码中的实际使用场景
4. 可以用作从wxWidgets迁移到其他框架的参考

## 统计信息

- **总计功能类别**: 25个主要类别
- **总计wx类/函数**: 超过200个
- **核心功能**: 字符串、文件、时间、几何、网络
- **重要发现**: ZIP归档、命令行框架、调试系统、单实例管理

最后更新: 基于KiCad源码的完整分析