# KiCad IPC System - Deep Learning Guide

This guide provides a comprehensive understanding of KiCad's IPC system through hands-on exploration of the minimal implementation.

## 📋 Table of Contents

1. [Prerequisites](#prerequisites)
2. [Understanding the IPC Architecture](#understanding-the-ipc-architecture)
3. [Hands-On Learning Path](#hands-on-learning-path)
4. [Code Deep Dive](#code-deep-dive)
5. [Advanced Topics](#advanced-topics)
6. [Real-World Applications](#real-world-applications)

## Prerequisites

### Knowledge Requirements
- **C++ fundamentals** (classes, pointers, memory management)
- **Basic networking concepts** (sockets, client-server architecture)
- **Python basics** (functions, classes, error handling)
- **Build systems** (CMake basics)

### Development Environment
- **OS**: Windows 10+ (Linux/macOS with minor modifications)
- **Compiler**: MSVC 2019+ or GCC 9+
- **Python**: 3.6 or later
- **Tools**: Git, CMake, protoc

## Understanding the IPC Architecture

### 1. What is IPC in KiCad?

IPC (Inter-Process Communication) allows external programs to:
- **Read** KiCad project data
- **Modify** design elements programmatically  
- **Control** KiCad's user interface
- **Automate** design workflows

### 2. Why Use IPC?

**Traditional Approach (Limitations):**
```
KiCad <---> File I/O <---> External Tool
```
- Slow (file read/write cycles)
- No real-time interaction
- Limited to file format capabilities
- Risk of data corruption

**IPC Approach (Advantages):**
```
KiCad <---> Socket <---> External Tool
```
- Fast (in-memory operations)
- Real-time bidirectional communication
- Full API access
- Safe, structured operations

### 3. Core Components

```
┌─────────────────────────────────────────────────────────────┐
│                    KiCad Process                            │
│  ┌─────────────────┐    ┌─────────────────┐                │
│  │   GUI Thread    │    │   IPC Thread    │                │
│  │                 │    │                 │                │
│  │ ┌─────────────┐ │    │ ┌─────────────┐ │                │
│  │ │   Canvas    │ │    │ │ IPC Server  │ │                │
│  │ │  (Objects)  │◄│────│►│ (Commands)  │ │                │
│  │ └─────────────┘ │    │ └─────────────┘ │                │
│  └─────────────────┘    └─────────────────┘                │
└─────────────────────────────────────────────────────────────┘
                                 │
                            Socket (IPC)
                                 │
┌─────────────────────────────────────────────────────────────┐
│                 External Process                            │
│  ┌─────────────────────────────────────────────────────────┐│
│  │              Python Client                              ││
│  │                                                         ││
│  │  ┌─────────────┐    ┌─────────────┐                    ││
│  │  │   Logic     │    │  Protobuf   │                    ││
│  │  │ (Commands)  │◄──►│ (Messages)  │                    ││
│  │  └─────────────┘    └─────────────┘                    ││
│  └─────────────────────────────────────────────────────────┘│
└─────────────────────────────────────────────────────────────┘
```

## Hands-On Learning Path

### Phase 1: Setup and Basic Understanding (30 minutes)

#### Step 1.1: Build and Run
```bash
# Build the project
cd minimal_kicad_ipc_system
cmake --preset windows-x64-debug
cmake --build build/debug

# Run the application
./build/debug/bin/minimal_kicad_ipc.exe
```

**🎯 Learning Goal:** Understand the basic GUI structure

**Key Observations:**
- Dark canvas with grid background
- Menu system with IPC controls
- Status bar showing current state

#### Step 1.2: Explore the GUI
1. **Create pads manually:**
   - Right-click on empty space
   - Select "Create Red/Green/Blue Pad"
   - Observe the pad appears instantly

2. **Interact with pads:**
   - Left-click to select (yellow outline)
   - Drag to move
   - Right-click to delete

**🤔 Question:** What data structure holds the pads? How are they drawn?

#### Step 1.3: Start the IPC Server
1. Go to **IPC → Start IPC Server**
2. Note the socket path in the dialog
3. Observe status bar changes to "IPC: Running"

**🎯 Learning Goal:** Understand the server startup process

### Phase 2: Python Client Interaction (45 minutes)

#### Step 2.1: Setup Python Environment
```bash
cd python_client

# Generate protobuf bindings
python generate_protobuf.py

# Install dependencies
pip install protobuf
```

**🎯 Learning Goal:** Understand the protobuf code generation process

**Key Files Created:**
- `minimal_ipc_pb2.py` - Python protobuf classes

#### Step 2.2: Run Basic Demo
```bash
python minimal_ipc_client.py
```

**Watch carefully as the client:**
1. **Connects** to the IPC server
2. **Sends a ping** to test connectivity
3. **Creates 3 pads** with different colors
4. **Moves one pad** to a new position
5. **Retrieves pad information**

**🤔 Questions:**
- How long does each operation take?
- Where do the pads appear on screen?
- What happens if you move pads manually while the script runs?

#### Step 2.3: Interactive Exploration
Choose "Interactive Mode" and try:

```
# Test connectivity
ping

# Create a custom pad
create my_pad 300 200 30 purple

# Move it around
move my_pad 400 250
move my_pad 500 300

# Check its properties
get my_pad

# Clean up
delete my_pad
```

**🎯 Learning Goal:** Experience the request/response cycle

### Phase 3: Code Analysis (60 minutes)

#### Step 3.1: Message Flow Tracing

**🔍 Exercise:** Trace a `move_pad` command from Python to GUI update

1. **Start Point:** `minimal_ipc_client.py:move_pad()`
```python
def move_pad(self, pad_id, new_x, new_y):
    request = minimal_ipc_pb2.IpcRequest()
    request.request_id = str(uuid.uuid4())
    request.move_pad.pad_id = pad_id
    request.move_pad.new_position.x = new_x
    request.move_pad.new_position.y = new_y
```

2. **Serialization:**
```python
request_data = request.SerializeToString()
self.socket.sendall(request_data)
```

3. **Server Receipt:** `minimal_ipc_server.cpp:ProcessRequest()`
```cpp
minimal_ipc::IpcRequest request;
if (!request.ParseFromString(*requestData)) {
    // Handle parse error
}
```

4. **Handler Dispatch:**
```cpp
case minimal_ipc::IpcRequest::kMovePad:
    response = HandleMovePadRequest(request.move_pad(), request.request_id());
    break;
```

5. **Canvas Update:** `minimal_pad_canvas.cpp:MovePad()`
```cpp
bool MinimalPadCanvas::MovePad(const std::string& padId, const wxPoint& newPosition) {
    MinimalPadItem* pad = GetPad(padId);
    if (pad) {
        pad->SetPosition(newPosition);
        RefreshCanvas();  // Triggers repaint
        return true;
    }
    return false;
}
```

**🤔 Deep Questions:**
- What happens if the Python client disconnects during a request?
- How does the GUI thread safely update objects from the IPC thread?
- What prevents race conditions between manual and IPC operations?

#### Step 3.2: Protobuf Deep Dive

**Examine the message definitions:**

```protobuf
// Basic coordinate type
message Point2D {
    double x = 1;
    double y = 2;
}

// The actual move command
message MovePadRequest {
    string pad_id = 1;
    Point2D new_position = 2;
}
```

**🔍 Exercise:** Add a new message type

1. **Add to the .proto file:**
```protobuf
message ChangePadColorRequest {
    string pad_id = 1;
    string new_color = 2;
}

message ChangePadColorResponse {
    Pad updated_pad = 1;
}
```

2. **Update the request union:**
```protobuf
message IpcRequest {
    // ... existing fields ...
    ChangePadColorRequest change_color = 7;  // Next available number
}

message IpcResponse {
    // ... existing fields ...
    ChangePadColorResponse change_color = 9;  // Next available number
}
```

3. **Regenerate Python bindings:**
```bash
python generate_protobuf.py
```

4. **Implement the server handler** (see [Advanced Topics](#advanced-topics))

#### Step 3.3: Threading Model Analysis

**🔍 Key Insight:** The IPC system bridges two threading domains:

```cpp
// IPC callback (runs on KINNG thread)
void MinimalIpcServer::ProcessRequest(std::string* requestData) {
    // Parse request on IPC thread
    minimal_ipc::IpcRequest request;
    request.ParseFromString(*requestData);
    
    // Create response on IPC thread
    minimal_ipc::IpcResponse response = HandleMovePadRequest(...);
    
    // Send response on IPC thread  
    m_server->Reply(response.SerializeAsString());
}

// Canvas update (must run on GUI thread)
bool MinimalPadCanvas::MovePad(...) {
    // This modifies GUI objects - MUST be on main thread
    pad->SetPosition(newPosition);
    RefreshCanvas();  // Triggers wxWidgets repaint
}
```

**🚨 Critical Point:** GUI operations MUST happen on the main thread!

**How KiCad Solves This:**
- IPC handlers process data on the IPC thread
- GUI modifications use wxWidgets' `CallAfter()` or similar mechanisms
- In our minimal implementation, we assume single-threaded for simplicity

### Phase 4: Advanced Understanding (90 minutes)

#### Step 4.1: Error Handling Deep Dive

**🔍 Exercise:** Trigger different error conditions:

1. **Protocol Errors:**
```python
# Send malformed request (modify the client temporarily)
self.socket.sendall(b"invalid data")
```

2. **Logic Errors:**
```python
# Try to move non-existent pad
client.move_pad("nonexistent", 100, 100)
```

3. **System Errors:**
```python
# Disconnect client suddenly (Ctrl+C during operation)
```

**Observe how each error is:**
- **Detected** (where in the code?)
- **Handled** (what recovery actions?)
- **Communicated** (error messages to client)

#### Step 4.2: Performance Analysis

**🔍 Experiment:** Measure operation latencies:

```python
import time

def measure_operation(operation_func):
    start = time.time()
    result = operation_func()
    end = time.time()
    print(f"Operation took {(end-start)*1000:.2f}ms")
    return result

# Test different operations
measure_operation(lambda: client.ping())
measure_operation(lambda: client.create_pad("test", 100, 100))
measure_operation(lambda: client.move_pad("test", 200, 200))
measure_operation(lambda: client.get_pads())
```

**🤔 Analysis Questions:**
- Which operations are fastest/slowest?
- What are the main bottlenecks?
- How does network latency affect local socket communication?

#### Step 4.3: Memory Management

**🔍 Exercise:** Track object lifecycle:

1. **Add logging to constructors/destructors:**
```cpp
MinimalPadItem::MinimalPadItem() {
    wxLogMessage("Creating pad: %s", m_id);
}

MinimalPadItem::~MinimalPadItem() {
    wxLogMessage("Destroying pad: %s", m_id);
}
```

2. **Create and delete many pads programmatically:**
```python
# Create 100 pads
for i in range(100):
    client.create_pad(f"pad_{i}", i*10, i*5, 15, "blue")

# Delete them all
for i in range(100):
    client.delete_pad(f"pad_{i}")
```

3. **Monitor memory usage** with task manager or similar tools

**🤔 Questions:**
- Are objects properly cleaned up?
- What happens to GPU resources (for drawing)?
- How does the protobuf library manage memory?

## Code Deep Dive

### Key Design Patterns

#### 1. **Request/Response Pattern**
```cpp
class MinimalIpcServer {
    // Each request type has a dedicated handler
    minimal_ipc::IpcResponse HandleMovePadRequest(
        const minimal_ipc::MovePadRequest& request,
        const std::string& requestId);
    
    // Handlers follow a consistent pattern:
    // 1. Validate input
    // 2. Perform operation
    // 3. Create response
    // 4. Return response
};
```

#### 2. **Serialization/Deserialization**
```cpp
// C++ side
minimal_ipc::Pad MinimalPadItem::ToProtobuf() const {
    minimal_ipc::Pad pad_proto;
    pad_proto.set_id(m_id);
    pad_proto.set_radius(m_radius);
    // ... etc
    return pad_proto;
}

void MinimalPadItem::FromProtobuf(const minimal_ipc::Pad& pad_proto) {
    m_id = pad_proto.id();
    m_radius = pad_proto.radius();
    // ... etc
}
```

```python
# Python side
def create_pad(self, pad_id, x, y, radius=20.0, color="blue"):
    request = minimal_ipc_pb2.IpcRequest()
    
    # Build request
    pad = request.create_pad.pad
    pad.id = pad_id
    pad.position.x = x
    pad.position.y = y
    # ... etc
    
    response = self.send_request(request)
    return response.success
```

#### 3. **Observer Pattern (Implicit)**
```cpp
// Canvas automatically redraws when objects change
class MinimalPadCanvas {
    bool MovePad(...) {
        // Modify object
        pad->SetPosition(newPosition);
        
        // Notify GUI system to repaint
        RefreshCanvas();  // Triggers OnPaint()
        return true;
    }
    
    void OnPaint(wxPaintEvent& event) {
        // Redraw all objects
        for (const auto& pad : m_pads) {
            pad->Draw(dc);
        }
    }
};
```

### Critical Code Sections

#### 1. **Socket Message Framing**

**Problem:** TCP sockets provide a stream of bytes, not discrete messages.

**Our Solution (Simplified):**
```cpp
// We assume each protobuf message is sent/received atomically
// This works for our demo but real systems need message framing:

// BETTER APPROACH (not implemented here):
// 1. Send message length first (4 bytes)
// 2. Send message content
// 3. Receiver reads length, then reads exact number of bytes

void ProcessRequest(std::string* requestData) {
    minimal_ipc::IpcRequest request;
    if (!request.ParseFromString(*requestData)) {
        // What if requestData contains partial message?
        // What if it contains multiple messages?
        // Our demo ignores these edge cases!
    }
}
```

#### 2. **Error Propagation**
```cpp
minimal_ipc::IpcResponse CreateErrorResponse(const std::string& requestId,
                                             const std::string& errorMessage) {
    minimal_ipc::IpcResponse response;
    response.set_request_id(requestId);
    response.set_success(false);           // Key: explicit success flag
    response.set_error_message(errorMessage);
    return response;
}
```

**🔍 Design Decision:** Every response has a `success` boolean and optional `error_message`. This makes error handling explicit and consistent.

#### 3. **Thread Safety**
```cpp
// CRITICAL: Our demo assumes single-threaded access to canvas
// Real KiCad uses thread-safe mechanisms:

bool MinimalPadCanvas::MovePad(...) {
    // In real KiCad, this would need:
    // 1. Lock acquisition
    // 2. Safe object modification  
    // 3. GUI update scheduling
    // 4. Lock release
    
    // Our simplified version:
    MinimalPadItem* pad = GetPad(padId);  // Not thread-safe!
    pad->SetPosition(newPosition);        // Not thread-safe!
    RefreshCanvas();                      // Not thread-safe!
}
```

## Advanced Topics

### Extending the Protocol

**🎯 Goal:** Add a "change pad color" command

#### Step 1: Update Protocol Definition
```protobuf
// Add to minimal_ipc.proto
message ChangePadColorRequest {
    string pad_id = 1;
    string new_color = 2;
}

message ChangePadColorResponse {
    Pad updated_pad = 1;
}

// Update IpcRequest
message IpcRequest {
    // ... existing oneofs ...
    ChangePadColorRequest change_color = 7;
}

// Update IpcResponse  
message IpcResponse {
    // ... existing oneofs ...
    ChangePadColorResponse change_color = 9;
}
```

#### Step 2: Implement Server Handler
```cpp
// Add to minimal_ipc_server.h
HANDLER_RESULT<ChangePadColorResponse> handleChangePadColor(
    const ChangePadColorRequest& request,
    const std::string& requestId);

// Add to minimal_ipc_server.cpp
minimal_ipc::IpcResponse MinimalIpcServer::HandleChangePadColorRequest(
    const minimal_ipc::ChangePadColorRequest& request,
    const std::string& requestId) {
    
    if (!m_canvas) {
        return CreateErrorResponse(requestId, "Canvas not available");
    }

    try {
        MinimalPadItem* pad = m_canvas->GetPad(request.pad_id());
        if (!pad) {
            return CreateErrorResponse(requestId, "Pad not found");
        }

        pad->SetColor(request.new_color());
        m_canvas->RefreshCanvas();

        minimal_ipc::IpcResponse response;
        response.set_request_id(requestId);
        response.set_success(true);
        
        minimal_ipc::ChangePadColorResponse* colorResponse = 
            response.mutable_change_color();
        *colorResponse->mutable_updated_pad() = pad->ToProtobuf();

        return response;
    }
    catch (const std::exception& e) {
        return CreateErrorResponse(requestId, 
            std::string("Change color error: ") + e.what());
    }
}

// Add to ProcessRequest switch statement
case minimal_ipc::IpcRequest::kChangeColor:
    response = HandleChangePadColorRequest(request.change_color(), request.request_id());
    break;
```

#### Step 3: Add Python Client Support
```python
def change_pad_color(self, pad_id, new_color):
    request = minimal_ipc_pb2.IpcRequest()
    request.request_id = str(uuid.uuid4())
    request.change_color.pad_id = pad_id
    request.change_color.new_color = new_color
    
    try:
        response = self.send_request(request)
        
        if response.success:
            updated_pad = response.change_color.updated_pad
            print(f"Pad color changed: {updated_pad.id} now {updated_pad.color}")
            return True
        else:
            print(f"Failed to change color: {response.error_message}")
            return False
            
    except Exception as e:
        print(f"Change color error: {e}")
        return False
```

### Performance Optimizations

#### 1. **Batch Operations**
```protobuf
// Instead of individual pad operations, support batches:
message BatchMovePadsRequest {
    repeated MovePadRequest moves = 1;
}

message BatchMovePadsResponse {
    repeated MovePadResponse results = 1;
}
```

#### 2. **Asynchronous Operations**
```protobuf
// For long-running operations:
message AsyncOperationRequest {
    string operation_id = 1;
    // ... operation details ...
}

message AsyncOperationResponse {
    string operation_id = 1;
    enum Status {
        STARTED = 0;
        IN_PROGRESS = 1;
        COMPLETED = 2;
        FAILED = 3;
    }
    Status status = 2;
    // ... progress info ...
}
```

#### 3. **Delta Updates**
```protobuf
// Instead of full object state, send only changes:
message PadDelta {
    string pad_id = 1;
    
    // Optional fields - only set if changed
    optional Point2D position = 2;
    optional double radius = 3;
    optional string color = 4;
}
```

### Security Considerations

**🚨 Important:** Our demo has NO security features!

**Real-world requirements:**
1. **Authentication:** Who can connect?
2. **Authorization:** What can they do?
3. **Input validation:** Prevent malicious requests
4. **Rate limiting:** Prevent DoS attacks
5. **Audit logging:** Track all operations

```cpp
// Example security handler:
class SecureIpcServer : public MinimalIpcServer {
    bool ValidateRequest(const IpcRequest& request) {
        // Check authentication token
        if (!IsValidToken(request.auth_token())) {
            return false;
        }
        
        // Check operation permissions
        if (!HasPermission(request.user_id(), request.command_case())) {
            return false;
        }
        
        // Validate input ranges
        if (!IsValidInput(request)) {
            return false;
        }
        
        return true;
    }
};
```

## Real-World Applications

### 1. **Automated PCB Layout**
```python
# Example: Auto-place components in a grid
def auto_place_components(client, components, grid_spacing=50):
    x, y = 100, 100  # Starting position
    
    for i, comp in enumerate(components):
        # Calculate grid position
        col = i % 10
        row = i // 10
        pos_x = x + col * grid_spacing
        pos_y = y + row * grid_spacing
        
        # Create component
        client.create_pad(comp['id'], pos_x, pos_y, 
                         comp['size'], comp['color'])
        
        print(f"Placed {comp['id']} at ({pos_x}, {pos_y})")
```

### 2. **Design Rule Checking**
```python
def check_minimum_spacing(client, min_distance=40):
    pads = client.get_pads()
    violations = []
    
    for i, pad1 in enumerate(pads):
        for pad2 in pads[i+1:]:
            distance = math.sqrt(
                (pad1['x'] - pad2['x'])**2 + 
                (pad1['y'] - pad2['y'])**2
            )
            
            if distance < min_distance:
                violations.append((pad1['id'], pad2['id'], distance))
    
    return violations
```

### 3. **Interactive Design Tools**
```python
def interactive_pad_editor(client):
    """Create a simple GUI tool for pad editing"""
    import tkinter as tk
    
    root = tk.Tk()
    root.title("Pad Editor")
    
    def create_pad():
        x = int(x_entry.get())
        y = int(y_entry.get())
        color = color_var.get()
        client.create_pad(f"gui_pad_{x}_{y}", x, y, 20, color)
    
    # GUI elements
    tk.Label(root, text="X:").pack()
    x_entry = tk.Entry(root)
    x_entry.pack()
    
    tk.Label(root, text="Y:").pack()
    y_entry = tk.Entry(root)
    y_entry.pack()
    
    color_var = tk.StringVar(value="blue")
    tk.OptionMenu(root, color_var, "red", "green", "blue").pack()
    
    tk.Button(root, text="Create Pad", command=create_pad).pack()
    
    root.mainloop()
```

### 4. **Data Analysis and Reporting**
```python
def analyze_pad_distribution(client):
    """Analyze the spatial distribution of pads"""
    pads = client.get_pads()
    
    if not pads:
        return "No pads to analyze"
    
    # Calculate statistics
    x_coords = [pad['x'] for pad in pads]
    y_coords = [pad['y'] for pad in pads]
    
    stats = {
        'count': len(pads),
        'x_range': (min(x_coords), max(x_coords)),
        'y_range': (min(y_coords), max(y_coords)),
        'center_x': sum(x_coords) / len(x_coords),
        'center_y': sum(y_coords) / len(y_coords),
        'colors': {color: sum(1 for p in pads if p['color'] == color) 
                  for color in set(pad['color'] for pad in pads)}
    }
    
    return stats
```

## Summary

**🎉 Congratulations!** You now understand:

✅ **Architecture:** How IPC enables cross-process communication  
✅ **Protocols:** How protobuf structures messages  
✅ **Threading:** How to safely bridge GUI and network threads  
✅ **Error Handling:** How to gracefully handle failures  
✅ **Extensions:** How to add new capabilities  
✅ **Performance:** What affects system responsiveness  
✅ **Security:** What real systems need to consider  
✅ **Applications:** How to build practical tools  

**🚀 Next Steps:**
1. Explore the full KiCad API documentation
2. Study real KiCad plugins for inspiration
3. Build your own automation tools
4. Contribute to the KiCad ecosystem!

**🧠 Key Insights:**
- IPC systems bridge different programming environments
- Message design affects usability and performance
- Threading requires careful coordination
- Error handling is crucial for reliable systems
- Security should be considered from the start

**Happy coding!** 🎯 